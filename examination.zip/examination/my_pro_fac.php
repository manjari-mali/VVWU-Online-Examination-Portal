<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: homepage.php"); // Redirect to login page if user is not logged in
    exit();
}

// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "examination";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = $_SESSION['email'];

// Retrieve user details from the database
$sql = "SELECT * FROM reg_fac WHERE email='$email'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output user details
    $row = $result->fetch_assoc();
} else {
    echo "No user found.";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
	<link rel="icon" href="image/logo.jpg" type="image/png">
    <link rel="stylesheet" href="styles.css">
    
    <style>
        .profile-box {
            max-width: 500px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .profile-box table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .profile-box table th,
        .profile-box table td {
            border: none;
            padding: 8px;
            text-align: left;
        }

        .profile-box table th {
            background-color: #f2f2f2;
        }

        .profile-box img {
			max-width: 100px;
            border-radius: 50%;
            margin-right: 40px; 
        }
    </style>
</head>
<body>
   
      
    <div class="profile-box">
       
             <img src="<?php echo $row['profile_pic']; ?>" alt="Profile Picture">
			 
        <table>
			
            <tr>
                <td><strong>Faculty ID:</strong></td>
                <td><?php echo $row['facid']; ?></td>
            </tr>
            <tr>
                <td><strong>Name:</strong></td>
                <td><?php echo $row['name']; ?></td>
            </tr>
            <tr>
                <td><strong>Email:</strong></td>
                <td><?php echo $row['email']; ?></td>
            </tr>
            <tr>
                <td><strong>Contact:</strong></td>
                <td><?php echo $row['contactno']; ?></td>
            </tr>
            <tr>
                <td><strong>Date of Birth:</strong></td>
                <td><?php echo $row['dob']; ?></td>
            </tr>
            <tr>
                <td><strong>Joining Date:</strong></td>
                <td><?php echo $row['doj']; ?></td>
            </tr>
            <tr>
                <td><strong>Gender:</strong></td>
                <td><?php echo $row['gender']; ?></td>
            </tr>
            <tr>
                <td><strong>Program:</strong></td>
                <td><?php echo $row['program']; ?></td>
            </tr>
            <tr>
                <td><strong>Course1:</strong></td>
                <td><?php echo $row['course1']; ?></td>
            </tr>
            <tr>
                <td><strong>Course2:</strong></td>
                <td><?php echo $row['course2']; ?></td>
            </tr>
            <tr>
                <td><strong>Course3:</strong></td>
                <td><?php echo $row['course3']; ?></td>
            </tr>
            <tr>
                <td><strong>Course4:</strong></td>
                <td><?php echo $row['course4']; ?></td>
            </tr>
        </table>
    </div>
   
</body>
</html>
