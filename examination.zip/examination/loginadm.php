<?php

session_start(); // Start the session

// Hardcoded username and password
$valid_username = "admin";
$valid_password = "admin@123";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if both username and password are provided
    if (!empty($_POST['username']) && !empty($_POST['password'])) {
        // Get the entered username and password from the form
        $entered_username = $_POST['username'];
        $entered_password = $_POST['password'];

        // Check if the entered username and password match the hardcoded values
        if ($entered_username === $valid_username && $entered_password === $valid_password) {
            // If the credentials are correct, set a session variable to indicate the user is logged in
            $_SESSION['logged_in'] = true;
            // Redirect to the dashboard page
            header("Location: dashboard_admin.php");
            exit;
        } else {
            // If the credentials are incorrect, display an error message
            $error_message = "Invalid username or password. Please try again.";
        }
    } else {
        // If either username or password is empty, display an error message
        $error_message = "Please enter both username and password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin - Examination Portal</title>
	<link rel="icon" href="image/logo.jpg" type="image/png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            align-items: center;
            height: 100vh;
            background-color: #f3f4f6;
        }
        main {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
  
        .login-container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 300px; /* Set a fixed height for vertical centering */
        }
        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 4px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }
  
        input[type="submit"] {
            width: 100%;
            background-color:#0066FF;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
  
        input[type="submit"]:hover {
            background-color:#90A4AE;
        }
        .login-symbol {
            display: block;
            margin: 0 auto;
            font-size: 48px;
            color: #007bff;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
<?php include 'header.html'; ?>
    <!-- Include navigation bar -->
    <?php include 'newnavigation.html'; ?>

    <!-- Login Form -->
    <br><br><br>
    <div class="login-container" >
        <span class="login-symbol">&#128272;</span>
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <input type="text" name="username" placeholder="&#128100; Username">
            <input type="password" name="password"  placeholder="&#128273; Password">
            <input type="submit" name="submit" class="login" value="Login">
            <?php
            // Display error message if exists
            if (isset($error_message)) {
                echo '<div style="color: red;">' . $error_message . '</div>';
            }
            ?>
        </form>
    </div>
   
    <!-- Include footer -->
    <?php include 'footer.html'; ?>
</body>
</html>
