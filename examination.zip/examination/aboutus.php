<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Examination Portal</title>
	<link rel="icon" href="image/logo.jpg" type="image/png">
    <link rel="stylesheet" href="styles.css">
    <style>
  body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f4f4f4;
  }
  .container {
    width: 80%;
    max-width: 800px;
    margin: 50px auto;
    background-color: #fff;
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }
  .header {
    text-align: center;
    margin-bottom: 20px;
  }
  .header h1 {
    color: #333;
  }
  .content {
    line-height: 1.6;
  }
  .content p {
    margin-bottom: 15px;
  }
  .content p:last-child {
    margin-bottom: 0;
  }
  .content-box {
    padding: 20px;
    border: 2px solid #333;
    border-radius: 10px;
    background-color: #f9f9f9;
  }
  
</style>
<!-- Include header -->
    <?php include 'header.html'; ?>
</head>
<body>
    <!-- Include navbar -->
    <?php include 'navigation.html'; ?>
<div class="container">
  <div class="header">
    <h1>Welcome to Vanita Vishram Women's University Online Examination Portal</h1>
  </div>
  <div class="content">
    <p>Vanita Vishram Women's University(VVWU) is the first-ever wmonen's university of Gujarat proposed under Public-Private-Partnership with the Government of Gujarat under the Gujarat Private Universities Act, 2009.</p>
    <p>VVWU is committed to provide quality education and employment opportunities to its girl students through its revamped curriculum and pedagogy. The focus is on prioritizing practical component and experiential learning supported through academia-industry linkages, functional MOUs, skill development training, internships etc. It aims at providing opportunities to the girl students for holistic development and self-reliance.</p>
	<h3>Vision:</h3>
    <p>Empowerment of women through quality education and skill development, So as to make them strong pillars of stability in the society.</p>
    <h3>Mission:</h3>
	<p>To provide education and professional training to all women for their all-round development, So as to enable them to become economically independent and socially empowered citizens.</p>
  </div>
  <br><br>
  <div class="content-box">
    <p>For more information, please visit our <a href="https://vvwusurat.ac.in/">website</a>.</p>
  </div>
</div>
  
    <!-- Include footer -->
    <?php include 'footer.html'; ?>
</body>
</html>
