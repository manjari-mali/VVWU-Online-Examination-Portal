<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam Results</title>
	<link rel="icon" href="image/logo.jpg" type="image/png">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f3f3f3;
            margin: 0;
            padding: 0;
        }

        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: #fff;
        }

        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
            border-right: 1px solid #ddd; /* Add right border to create partitions */
            color: #555; /* Change text color */
        }

        th:last-child,
        td:last-child {
            border-right: none; /* Remove right border for the last column */
        }

        th {
            background-color: #4e7ab8; /* Dark red background */
            color: #fff; /* White text color */
            font-weight: bold;
            text-transform: uppercase;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .download-button {
            padding: 10px 20px;
            background-color: #4e7ab8;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .download-container {
            text-align: right;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <?php
    // Connect to the database
    $conn = new mysqli('localhost', 'root', '', 'examination');

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Query to select username, score, and date from exam_result table
    $query = "SELECT email, score, percentage, date FROM result_table";

    // Execute the query
    $result = $conn->query($query);

    // Check if there are any rows returned
    if ($result->num_rows > 0) {
        // Start table
        echo "<table>";
        echo "<tr><th>Email</th><th>Score</th><th>Percentage</th><th>Date</th></tr>";

        // Output data of each row
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["email"] . "</td>";
            echo "<td>" . $row["score"] . "</td>";
            echo "<td>" . $row["percentage"] . "</td>";
            echo "<td>" . $row["date"] . "</td>";
            echo "</tr>";
        }

        // Download button row
        echo "<tr><td colspan='4'>";
        echo "<div class='download-container'>";
        echo "<form method='post' action='download.php'>";
        echo "<input type='submit' class='download-button' name='download_csv' value='Download Result'>";
        echo "</form>";
        echo "</div>";
        echo "</td></tr>";

        // End table
        echo "</table>";
    } else {
        echo "0 results";
    }

    // Close the database connection
    $conn->close();
    ?>
</body>
</html>