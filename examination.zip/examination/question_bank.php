<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Attractive Buttons</title>
  <link rel="icon" href="image/logo.jpg" type="image/png">
  <style>
    .button-container {
      border: 2px solid #3498db; /* Adjust border color as needed */
      border-radius: 10px; /* Rounded corners */
      padding: 20px;
      width: auto; /* Adjust width as needed */
    }

    .btn {
      display: block;
      width: 300px; /* Full width within table cell */
      height:200px;
	  margin-bottom: 10px;
      padding: 10px 20px;
      font-size: 16px;
      border: none;
      border-radius: 5px;
      cursor: pointer; /* Hand cursor on hover for clickability */
      transition: background-color 0.3s ease; /* Smooth color transition */
      background-color: #e7e7e7; /* Light gray background for all buttons */
      color: #333; /* Dark gray text color */
    }

    .btn:hover {
      background-color: #cccccc; /* Slightly darker gray on hover */
    }

    /* Removed unused individual button styles (.btn1, .btn2) */

    /* Table structure styles */
    table {
      border-collapse: collapse; /* Remove table borders */
    }

    td {
      padding: 5px; /* Add spacing between buttons */
      text-align: center; /* Center buttons horizontally */
    }
  </style>
</head>
<body>
  <div class="button-container">
    <table>
      <tr>
        <td><a href="icoa.php"><button class="btn">CS11010-ICOA</button></a></td>
        <td><a href="c.php"><button class="btn">CS11030-Programming Using C</button></a></td>
        <td><a href="c++.php"><button class="btn">CS11050-Programming Using C++</button></a></td>
		<td><a href="unix.php"><button class="btn">CS11070-Operating System With UNIX</button></a></td>
      </tr>
      <tr>
        <td><a href="ds.php"><button class="btn">CS11090-Data Structure</button></a></td>
        <td><a href="java.php"><button class="btn">CS11130-Programming Using JAVA</button></a></td>
		<td><a href="python.php"><button class="btn">CS11160-Programming Using Python</button></a></td>
		<td><a href="iot.php"><button class="btn">CS51020-Internet Of Things</button></a></td>
      </tr>
	  <tr>
        <td><a href="cg.php"><button class="btn">CS11210-Computer Graphics</button></a></td>
        <td><a href="php.php"><button class="btn">CS11220-Web Development Using PHP</button></a></td>
		<td><a href="cs.php"><button class="btn">CS14090-Cyber Security</button></a></td>
		<td><a href="dm.php"><button class="btn">CS14110-Digital Marketing</button></a></td>
      </tr>
      </table>
  </div>
</body>
</html>
