<?php
session_start();

// Establish a connection to your database
$servername = "localhost"; // Change this to your MySQL server address
$username = "root"; // Change this to your MySQL username
$password = ""; // Change this to your MySQL password
$dbname = "examination"; // Change this to your MySQL database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Escape user inputs for security
$rollno = mysqli_real_escape_string($conn, $_POST['rollno']);
$name = mysqli_real_escape_string($conn, $_POST['name']);
$email = mysqli_real_escape_string($conn, $_POST['email']);
$password = mysqli_real_escape_string($conn, $_POST['password']);
$contactno = mysqli_real_escape_string($conn, $_POST['contactno']);
$dob = mysqli_real_escape_string($conn, $_POST['dob']);
$program = mysqli_real_escape_string($conn, $_POST['program']);
$year = mysqli_real_escape_string($conn, $_POST['year']);
$sem = mysqli_real_escape_string($conn, $_POST['sem']);
$div = mysqli_real_escape_string($conn, $_POST['div']);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Escape user inputs for security
    $rollno = $conn->real_escape_string($_POST['rollno']);
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = $conn->real_escape_string($_POST['password']);
    $contactno = $conn->real_escape_string($_POST['contactno']);
    $dob = $conn->real_escape_string($_POST['dob']);
    $program = $conn->real_escape_string($_POST['program']);
    $year = $conn->real_escape_string($_POST['year']);
    $sem = $conn->real_escape_string($_POST['sem']);
    $div = $conn->real_escape_string($_POST['div']);
	
    // File upload handling
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["profile_pic"]["name"]);
    move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $target_file);
    
    // SQL query to insert data into database
    $sql = "INSERT INTO reg_stu (rollno, name, email, password, contactno, dob, program, year, sem, `div`, profile_pic) 
    VALUES ('$rollno', '$name', '$email', '$password', '$contactno', '$dob', '$program', '$year', '$sem', '$div', '$target_file')";

	if ($conn->query($sql) === TRUE) {
    $_SESSION['status'] = "Student registered successfully";
    header("Location: register_student.php"); // Redirect back to the form page
    exit();
	} else {
		$_SESSION['status'] = "Error: " . $sql . "<br>" . $conn->error;
		header("Location: register_student.php"); // Redirect back to the form page
		exit();
	}
}

// Close connection
$conn->close();
?>
