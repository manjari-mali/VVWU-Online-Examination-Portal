<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: homepage.php"); // Redirect to login page if user is not logged in
    exit();
}

// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "examination";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = $_SESSION['email'];

// Retrieve user details from the database
$sql = "SELECT * FROM reg_stu WHERE email='$email'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output user details
    $row = $result->fetch_assoc();
} else {
    echo "No user found.";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
	<link rel="icon" href="image/logo.jpg" type="image/png">
    <link rel="stylesheet" href="styles.css">
    
    <style>
        .profile-box {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .profile-box img {
            max-width: 100px;
            border-radius: 50%;
            margin-bottom: 10px;
			margin: 0 auto 10px;
			display: block;
        }

        .profile-box p {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
   
      
    <div class="profile-box">
        <img src="<?php echo $row['profile_pic']; ?>" alt="Profile Picture">
        <p><strong>Student ID:</strong> <?php echo $row['rollno']; ?></p>
        <p><strong>Name:</strong> <?php echo $row['name']; ?></p>
        <p><strong>Email:</strong> <?php echo $row['email']; ?></p>
        <p><strong>Contact:</strong> <?php echo $row['contactno']; ?></p>
		<p><strong>Date of Birth:</strong> <?php echo $row['dob']; ?></p>
		<p><strong>Program:</strong> <?php echo $row['program']; ?></p>
        <p><strong>Year:</strong> <?php echo $row['year']; ?></p>
		<p><strong>Semester:</strong><?php echo $row['sem']; ?></p> 
		<p><strong>Division:</strong><?php echo $row['div']; ?></p> 
		
    </div>
   
</body>
</html>
