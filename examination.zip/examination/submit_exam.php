<?php
// Start or resume the session
session_start();

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "examination";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to fetch questions and correct answers
$sql = "SELECT id, que, right_ans FROM qbco4 LIMIT 10";
$result = $conn->query($sql);

$score = 0;
$total_questions = $result->num_rows;

if ($total_questions > 0) {
    // Output data of each row
    while ($row = $result->fetch_assoc()) {
        $question_id = $row["id"];
        $correct_option = $row["right_ans"];
        $user_option = isset($_POST['answers'][$question_id]) ? $_POST['answers'][$question_id] : '';

        // Increment score if the user's answer is correct
        if ($user_option == $correct_option) {
            $score++;
        }
    }
}

// Define CSS styling
echo "<style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #f9f9f9;
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }
    .container {
        background-color: #fff;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        text-align: center;
        max-width: 500px;
        width: 90%;
    }
    .score {
        font-weight: bold;
        color: blue;
        font-size: 24px;
    }
    .center {
        text-align: center;
        margin-bottom: 20px;
    }
    .feedback-button {
        background-color: #4e7ab8;
        border: none;
        color: white;
        padding: 15px 32px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin-top: 20px;
        cursor: pointer;
        border-radius: 5px;
        transition: background-color 0.3s ease;
    }
    .feedback-button:hover {
        background-color: #5d8cc9 ;
    }
</style>";

// Output quiz results
echo "<div class='container'>";
echo "<h2>Your Result</h2>";
echo "<p class='center'>Congratulations!</p>";
echo "<p class='center'>Your score is: <span class='score'>" . $score . "</span></p>";
echo "<p class='center'>Total Questions: $total_questions</p>";
$percentage = ($score / $total_questions) * 100;
echo "<p class='center'>Percentage: $percentage%</p>";

// Add a feedback button
echo "<form action='feedback.php' method='get'>";
echo "<button type='submit' class='feedback-button'>Give Feedback</button>";
echo "</form>";

// Get current date and time
$current_date_time = date("Y-m-d H:i:s");

// Get email from session
$email = isset($_SESSION['email']) ? $_SESSION['email'] : '';

// Insert score into the database
$sql_insert = "INSERT INTO result_table (email, score, percentage, date, time) VALUES (?, ?, ?, NOW(), NOW())";
$stmt = $conn->prepare($sql_insert);
if ($stmt) {
    $stmt->bind_param("sii", $email, $score, $percentage);
    $stmt->execute();
    $stmt->close();
} else {
    echo "Error preparing statement: " . $conn->error;
}

echo "</div>"; // Close container

// Close connection
$conn->close();
?>
