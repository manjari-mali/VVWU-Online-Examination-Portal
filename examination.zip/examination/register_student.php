<?php
session_start();

// Sample array representing semesters for each year
$semesters = array(
    '1' => array('1', '2'),
    '2' => array('3', '4'),
    '3' => array('5', '6'),
);

// Sample array representing courses for each semester for each year
$courses = array(
    '1' => array(
        '1' => array('ICOA', 'Programming Using C'),
        '2' => array('Programming Using C++', 'Operating System With UNIX'),
    ),
    '2' => array(
        '3' => array('Data Structure', 'Programming Using JAVA'),
        '4' => array('Programming Using Python', 'Internet Of Things'),
    ),
    '3' => array(
        '5' => array('Computer Graphics', 'Web Development Using PHP'),
        '6' => array('Cyber Security', 'Digital Marketing'),
    ),
);

$selectedYear = isset($_POST['year']) ? $_POST['year'] : '';
$selectedSemester = isset($_POST['sem']) ? $_POST['sem'] : '';
$selectedCourse = isset($_POST['course']) ? $_POST['course'] : '';

?>




<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration Form</title>
	<link rel="icon" href="image/logo.jpg" type="image/png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
	 <style>
        /* Additional CSS for form styling */
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: #4e7ab8;
            color: #fff;
            border-radius: 10px 10px 0 0;
        }

        .form-group label {
            font-weight: bold;
            color: #333;
        }

        .btn-primary {
            background-color: #4e7ab8;
            border: none;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        input[type="datetime-local"],
        select.form-control {
            border: 1px solid #ced4da;
            border-radius: 5px;
            padding: 0.375rem 0.75rem;
            font-size: 1rem;
            line-height: 1.5;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }
    </style>
</head>
<body>
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-md-8">
					<?php
					if (isset($_SESSION['status'])) {
						?>
						<div class="alert alert-warning alert-dismissible fade show" role="alert">
							<?php echo $_SESSION['status']; ?>
							<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
						</div>
						<?php
						unset($_SESSION['status']);
					}
					?>
				<div class="card mt-5">
						<div class="card-header">
							<h4>Student Registration Form</h4>
						</div>
					<div class="card-body">
					
							<form method="post" action="register_stu.php" enctype="multipart/form-data"> <!--upload_schedule.php-->
								
								<div class="form-group mb-3">
									<label for="rollno">Roll No:</label>
									<input type="text" id="rollno" name="rollno" class="form-control" required>
								</div>
								
								<div class="form-group mb-3">
									<label for="name">Student Name :</label>
									<input type="text" id="name" name="name" class="form-control" required>
								</div>
								
								<div class="form-group mb-3">
									<label for="email">Email:</label>
									<input type="email" id="email" name="email" class="form-control" pattern=".+@vvwusurat\.ac\.in$" required>
								</div>
								
								<div class="form-group mb-3">
									<label for="password">Password:</label>
									<input type="password" id="password" name="password" class="form-control" minlength="6" required>
								</div>
								
								<div class="form-group mb-3">
									<label for="contactno">Contact Number:</label>
									<input type="text" id="contactno" name="contactno" class="form-control" pattern="[0-9]{10}" required>
								</div>
								
								<div class="form-group mb-3">
									<label for="dob">Date of Birth:</label>
									<input type="date" id="dob" name="dob" class="form-control" required>
								</div>
								
								<div class="form-group mb-3">
									<label for="program">Program:</label>
									<select name="program" id="program" class="form-control">
										<option value="BCA" selected>Bachelor of Computer Application(Hons.)</option>
									</select>
								</div>
								
								<div class="form-group mb-3">
									<label for="year">Year:</label>
									<select name="year" id="year" class="form-control" onchange="updateSemesters()">
										<option value="">Select Year</option>
										<?php foreach ($semesters as $year => $year_semesters): ?>
											<option value="<?php echo $year; ?>"
												<?php echo ($selectedYear == $year) ? 'selected' : ''; ?>><?php echo $year; ?></option>
										<?php endforeach; ?>
									</select>
								</div>
								
								<div class="form-group mb-3">
									<label for="sem">Semester:</label>
									 <select name="sem" id="semester" class="form-control" onchange="updateCourses()">
										<option value="">Select Semester</option>
									</select>
								</div>
								
								<div class="form-group mb-3">
									<label for="div">Division:</label>
									<select id="div" name="div" class="form-control" required>
										<option value="" disabled selected>Select Division</option>
										<option value="A">A</option>
										<option value="B">B</option>
										<option value="C">C</option>
										<option value="D">D</option>
										<option value="E">E</option>
									</select>
								</div>
								
								<div class="form-group mb-3">
									<label for="profile_pic">Profile Picture:</label>
									<input type="file" id="profile_pic" name="profile_pic" class="form-control" >
								</div>
								<div class="form-group mb-3">
									<button type="submit" name="submit" class="btn btn-primary">Upload</button>
								<!--<input type="submit" name="submit" value="Submit"> -->
								</div>
							</form>	
						</div>
					</div>
				</div>
			</div>
		<div>
		
		
<script>
    var courses = <?php echo json_encode($courses); ?>;

    function updateSemesters() {
        var yearSelect = document.getElementById("year");
        var semesterSelect = document.getElementById("semester");
        var selectedYear = yearSelect.value;
        semesterSelect.innerHTML = ''; // Clear previous options

        if (selectedYear !== '') {
            var yearSemesters = courses[selectedYear];
            for (var semester in yearSemesters) {
                var option = document.createElement("option");
                option.value = semester;
                option.text = semester;
                semesterSelect.appendChild(option);
            }
            updateCourses(); // Update courses when year changes
        } else {
            var option = document.createElement("option");
            option.text = 'Select Semester';
            semesterSelect.appendChild(option);
        }
    }

    function updateCourses() {
        var yearSelect = document.getElementById("year");
        var semesterSelect = document.getElementById("semester");
        var courseSelect = document.getElementById("course");
        var selectedYear = yearSelect.value;
        var selectedSemester = semesterSelect.value;
        courseSelect.innerHTML = ''; // Clear previous options

        if (selectedYear !== '' && selectedSemester !== '') {
            var semesterCourses = courses[selectedYear][selectedSemester];
            for (var i = 0; i < semesterCourses.length; i++) {
                var option = document.createElement("option");
                option.value = semesterCourses[i];
                option.text = semesterCourses[i];
                courseSelect.appendChild(option);
            }
        } else {
            var option = document.createElement("option");
            option.text = 'Select Course';
            courseSelect.appendChild(option);
        }
    }

    // Initialize the dropdowns
    updateSemesters();
</script>

<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
		
	</body>
</html>
