<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['email'])) {
    // Redirect user to login page if not logged in
    header("Location: homepage.php");
    exit(); // Stop further execution
}

// Check if the course parameter is set in the URL
if (isset($_GET['course'])) {
    // Retrieve the course information from the URL parameter
    $course = $_GET['course'];

    // Sanitize the course input
    $sanitized_course = htmlspecialchars($course);

    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'examination');

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Sanitize the course input to prevent SQL injection
    $sanitized_course = $conn->real_escape_string($sanitized_course);

    // Get the table name based on the course
    switch ($sanitized_course) {
        case 'ICOA':
            $table = 'qbco1';
            break;
        case 'Programming Using C':
            $table = 'qbco2';
            break;
        case 'Programming Using C++':
            $table = 'qbco3';
            break;
        case 'Operating System With UNIX':
            $table = 'qbco4';
            break;
        case 'Data Structure':
            $table = 'qbco5';
            break;
        case 'Programming Using JAVA':
            $table = 'qbco6';
            break;
        case 'Programming Using Python':
            $table = 'qbco7';
            break;
        case 'Internet Of Things':
            $table = 'qbco8';
            break;
        case 'Computer Graphics':
            $table = 'qbco9';
            break;
        case 'Web Development Using PHP':
            $table = 'qbco10';
            break;
        case 'Cyber Security':
            $table = 'qbco11';
            break;
        case 'Digital Marketing':
            $table = 'qbco12';
            break;
        default:
            echo "Sorry for the inconvenience. Please contact the administrator to get the question paper.";
            exit(); // Stop further execution
            break;
    }

    // Fetch 10 random questions and options from the course table
    $questions_sql = "SELECT id, que, optiona, optionb, optionc, optiond FROM $table ORDER BY RAND() LIMIT 10";

    $questions_result = $conn->query($questions_sql);
    if (!$questions_result) {
        echo "Error fetching questions: " . $conn->error;
        exit(); // Stop further execution
    }

    if ($questions_result && $questions_result->num_rows > 0) {
        // Echo HTML for exam questions form
        echo "<div class='container'>";
        echo "<div class='box'>";
        echo "<h2>MCQ Test</h2>"; // Moved timer below this line
        echo "<div class='timer-container'>"; // Timer container
        echo "<div id='timer'>Time : <span id='minutes'>15</span>:<span id='seconds'>00</span> </div>"; // Timer display
        echo "</div>"; // Closing timer-container div
        echo "<form id='examForm' action='submit_exam.php' method='post'>";
        $question_number = 1; // Initialize question number counter
        while ($question_row = $questions_result->fetch_assoc()) {
            echo "<p>" . $question_number . ". " . $question_row['que'] . "</p>";
            echo "<input type='hidden' name='question_ids[]' value='" . $question_row['id'] . "'>";
            echo "<input type='radio' name='answers[" . $question_row['id'] . "]' value='" . $question_row['optiona'] . "'>" . $question_row['optiona'] . "<br>";
            echo "<input type='radio' name='answers[" . $question_row['id'] . "]' value='" . $question_row['optionb'] . "'>" . $question_row['optionb'] . "<br>";
            echo "<input type='radio' name='answers[" . $question_row['id'] . "]' value='" . $question_row['optionc'] . "'>" . $question_row['optionc'] . "<br>";
            echo "<input type='radio' name='answers[" . $question_row['id'] . "]' value='" . $question_row['optiond'] . "'>" . $question_row['optiond'] . "<br><br>";
            $question_number++; // Increment question number counter
        }
        echo "<input type='submit' id='submitButton' value='Submit'>";
        echo "</form>";
        echo "</div>"; // Closing box div
        echo "</div>"; // Closing container div
    } else {
        echo "No questions found for Course: $sanitized_course";
    }

    // Close database connection
    $conn->close();
} else {
    echo "Error: Course parameter not set.";
}
?>
<script>
// JavaScript for timer
var minutesLabel = document.getElementById("minutes");
var secondsLabel = document.getElementById("seconds");
var totalSeconds = 900; // 15 minutes

setInterval(setTime, 1000);

function setTime() {
  --totalSeconds;
  var minutes = Math.floor(totalSeconds / 60);
  var seconds = totalSeconds % 60;

  minutesLabel.innerHTML = pad(minutes);
  secondsLabel.innerHTML = pad(seconds);

  if (totalSeconds <= 0) {
    clearInterval(setTime);
    alert("Time's up!");
    document.getElementById("examForm").submit(); // Submit the form when time is up
  }
}

function pad(val) {
  var valString = val + "";
  if (valString.length < 2) {
    return "0" + valString;
  } else {
    return valString;
  }
}

// JavaScript to make submit button blur after clicking
document.getElementById("submitButton").addEventListener("click", function() {
  this.blur();
});

// JavaScript to prevent viewing or copying source code
const disabledKeys = ["c", "C", "x", "J", "u", "I"]; // keys that will be disabled
const showAlert = (e) => {
    e.preventDefault(); // preventing its default behaviour
    return alert("Sorry, you can't view or copy source codes this way!");
};
document.addEventListener("contextmenu", (e) => {
    showAlert(e); // calling showAlert() function on mouse right click
});
document.addEventListener("keydown", (e) => {
    // calling showAlert() function, if the pressed key matched to disabled keys
    if ((e.ctrlKey && disabledKeys.includes(e.key)) || e.key === "F12") {
        showAlert(e);
    }
});
</script>
<style>
.container {
  width: 50%;
  margin: 0 auto;
}

.box {
  border: 1px solid #ccc;
  border-radius: 5px;
  padding: 20px;
  margin-bottom: 20px;
}

.timer-container {
  float: right;
  margin-top: -40px; /* Adjust this value as needed */
}

#timer {
  font-size: 20px;
  font-weight: bold;
}

#submitButton {
  background-color: #007bff; /* Blue color for normal state */
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  font-size: 18px;
  cursor: pointer;
  transition: background-color 0.3s;
}

#submitButton:hover {
  background-color: #0069d9; /* Slightly lighter blue color for hover */
}

#submitButton:active {
  background-color: #0056b3; /* Even lighter blue color for active */
}


</style>
