<?php
session_start();

// Establish a connection to your database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "examination";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Escape user inputs for security
$facid = mysqli_real_escape_string($conn, $_POST['facid']);
$name = mysqli_real_escape_string($conn, $_POST['name']);
$email = mysqli_real_escape_string($conn, $_POST['email']);
$password = mysqli_real_escape_string($conn, $_POST['password']);
$dob = mysqli_real_escape_string($conn, $_POST['dob']);
$doj = mysqli_real_escape_string($conn, $_POST['doj']);
$gender = mysqli_real_escape_string($conn, $_POST['gender']);
$program = mysqli_real_escape_string($conn, $_POST['program']);
$course1 = mysqli_real_escape_string($conn, $_POST['course1']);
$course2 = mysqli_real_escape_string($conn, $_POST['course2']);
$course3 = mysqli_real_escape_string($conn, $_POST['course3']);
$course4 = mysqli_real_escape_string($conn, $_POST['course4']);


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Escape user inputs for security
	$facid = $conn->real_escape_string($_POST['facid']);
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = $conn->real_escape_string($_POST['password']);
    $dob = $conn->real_escape_string($_POST['dob']);
    $doj = $conn->real_escape_string($_POST['doj']);
    $gender = $conn->real_escape_string($_POST['gender']);
    $program = $conn->real_escape_string($_POST['program']);
    $course1 = $conn->real_escape_string($_POST['course1']);
    $course2 = $conn->real_escape_string($_POST['course2']);
    $course3 = $conn->real_escape_string($_POST['course3']);
    $course4 = $conn->real_escape_string($_POST['course4']);

    // File upload handling
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["profile_pic"]["name"]);
    move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $target_file);

    // Insert data into database
    $sql = "INSERT INTO reg_fac (facid, name, email, password, dob, doj, gender, program, course1, course2, course3, course4, profile_pic)
	VALUES ('$facid', '$name', '$email', '$password', '$dob', '$doj', '$gender', '$program', '$course1', '$course2', '$course3', '$course4', '$target_file')";

if ($conn->query($sql) === TRUE) {
    $_SESSION['status'] = "Faculty registered successfully";
    header("Location: register_faculty.php");  // Redirect to login page
    exit();
} else {
    $_SESSION['status'] = "Error: " . $sql . "<br>" . $conn->error;
    header("Location: register_faculty.php");
    exit();
}

}

$conn->close();
?>
