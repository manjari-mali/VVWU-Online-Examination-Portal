<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CS11010-ICOA Questions</title>
  <link rel="icon" href="image/logo.jpg" type="image/png">
  <style>
    /* Your CSS styles */
    
	body {
      font-family: Arial, sans-serif;
      background-color: #f2f2f2;
    }

    .container {
      max-width: 800px;
      margin: 0 auto;
      padding: 20px;
      background-color: #fff;
      border-radius: 8px;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
    }

    h1 {
      text-align: center;
      margin-bottom: 20px;
    }

    button {
      background-color: #007bff;
      color: #fff;
      border: none;
      padding: 10px 20px;
      cursor: pointer;
      border-radius: 5px;
      transition: background-color 0.3s;
    }

    button:hover {
      background-color: #0056b3;
    }

    .popup-form {
      display: none;
      position: fixed;
      top: 50%;
      left: 50%;
	  width: 400px;
      transform: translate(-50%, -50%);
      background-color: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      z-index: 9999;
    }

    form label {
      display: block;
      margin-bottom: 5px;
    }

    form input[type="text"],
    form select {
      width: 100%;
      padding: 8px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }

    form button[type="submit"],
    form button[type="button"] {
      background-color: #28a745;
      color: #fff;
      border: none;
      padding: 10px 20px;
      cursor: pointer;
      border-radius: 5px;
      transition: background-color 0.3s;
    }

    form button[type="submit"]:hover,
    form button[type="button"]:hover {
      background-color: #218838;
    }

    .question {
      margin-bottom: 20px;
      border: 1px solid #ccc;
      border-radius: 8px;
      padding: 10px;
    }

    .option {
      margin-bottom: 5px;
    }

    .btn-update,
    .btn-delete {
      background-color: #dc3545;
      color: #fff;
      border: none;
      padding: 5px 10px;
      cursor: pointer;
      border-radius: 5px;
      transition: background-color 0.3s;
    }

    .btn-update:hover,
    .btn-delete:hover {
      background-color: #c82333;
    }

    .button-container {
      margin-top: 10px;
    }

    .button-container form {
      display: inline;
      margin-right: 10px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1><center>CS11010-ICOA Questions</center></h1>
    <button onclick="showAddForm()">Add Question</button>
    <div class="popup-form" id="add-form">
      <h2>Add Question</h2>
      <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="add-id">ID:</label><br>
        <input type="text" id="add-id" name="add_id"><br>
        <label for="add-question">Question:</label><br>
        <input type="text" id="add-question" name="add_question"><br>
        <label for="add-optiona">Option A:</label><br>
        <input type="text" id="add-optiona" name="add_optiona"><br>
        <label for="add-optionb">Option B:</label><br>
        <input type="text" id="add-optionb" name="add_optionb"><br>
        <label for="add-optionc">Option C:</label><br>
        <input type="text" id="add-optionc" name="add_optionc"><br>
        <label for="add-optiond">Option D:</label><br>
        <input type="text" id="add-optiond" name="add_optiond"><br>
        <label for="add-right-ans">Correct Answer:</label><br>
        <select id="add-right-ans" name="add_right_ans">
            <option value="optiona">Option A</option>
            <option value="optionb">Option B</option>
            <option value="optionc">Option C</option>
            <option value="optiond">Option D</option>
        </select><br>
        <button type="submit">Add</button>
        <button type="button" onclick="hideAddForm()">Cancel</button>
      </form>
    </div>
    <div id="update-form" style="display: none;">
        <h2>Update Question</h2>
        <form method="post">
            <input type="hidden" id="update-id" name="update_id">
            <label for="updated-question">Question:</label><br>
            <input type="text" id="updated-question" name="updated_question"><br>
            <label for="updated-optiona">Option A:</label><br>
            <input type="text" id="updated-optiona" name="updated_optiona"><br>
            <label for="updated-optionb">Option B:</label><br>
            <input type="text" id="updated-optionb" name="updated_optionb"><br>
            <label for="updated-optionc">Option C:</label><br>
            <input type="text" id="updated-optionc" name="updated_optionc"><br>
            <label for="updated-optiond">Option D:</label><br>
            <input type="text" id="updated-optiond" name="updated_optiond"><br>
            <label for="updated-right-ans">Correct Answer:</label><br>
            <select id="updated-right-ans" name="updated_right_ans">
                <option value="optiona">Option A</option>
                <option value="optionb">Option B</option>
                <option value="optionc">Option C</option>
                <option value="optiond">Option D</option>
            </select><br>
            <button type="submit">Update</button>
            <button type="button" onclick="hideUpdateForm()">Cancel</button>
        </form>
    </div>

    <?php
    // Establish database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "examination";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Handle form submission for adding new question
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_question'])) {
        $courseid = 2; // Default value for courseid
        $id = $_POST['add_id'];
        $que = $_POST['add_question'];
        $optiona = $_POST['add_optiona'];
        $optionb = $_POST['add_optionb'];
        $optionc = $_POST['add_optionc'];
        $optiond = $_POST['add_optiond'];
        $right_ans = $_POST['add_right_ans'];

        // Insert data into the database
        $sql = "INSERT INTO qbco1 (id, courseid, que, optiona, optionb, optionc, optiond, right_ans)
                VALUES ('$id', '$courseid', '$que', '$optiona', '$optionb', '$optionc', '$optiond', '$right_ans')";

        if ($conn->query($sql) === TRUE) {
            echo "New record created successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    // Handle form submission for updating existing question
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_id'])) {
        $update_id = $_POST['update_id'];
        $updated_question = $_POST['updated_question'];
        $updated_optiona = $_POST['updated_optiona'];
        $updated_optionb = $_POST['updated_optionb'];
        $updated_optionc = $_POST['updated_optionc'];
        $updated_optiond = $_POST['updated_optiond'];
        $updated_right_ans = $_POST['updated_right_ans'];

        // Perform the update operation
        $sql_update = "UPDATE qbco1 SET que='$updated_question', optiona='$updated_optiona', optionb='$updated_optionb', optionc='$updated_optionc', optiond='$updated_optiond', right_ans='$updated_right_ans' WHERE id=$update_id";
        if ($conn->query($sql_update) === TRUE) {
            echo "Record updated successfully";
        } else {
            echo "Error updating record: " . $conn->error;
        }
    }

    // Handle form submission for deleting a question
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_id'])) {
        $delete_id = $_POST['delete_id'];

        // Perform the delete operation
        $sql_delete = "DELETE FROM qbco1 WHERE id=$delete_id";
        if ($conn->query($sql_delete) === TRUE) {
            echo "Record deleted successfully";
        } else {
            echo "Error deleting record: " . $conn->error;
        }
    }

    // Fetch questions from database
    $sql = "SELECT id, que, optiona, optionb, optionc, optiond, right_ans FROM qbco1";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo '<div class="question">';
            echo '<p class="question-text">Question ID: ' . $row["id"] . '</p>';
            echo '<p class="question-text">Question: ' . $row["que"] . '</p>';
            echo '<div class="options">';
            echo '<p class="option">Option A: ' . $row["optiona"] . '</p>';
            echo '<p class="option">Option B: ' . $row["optionb"] . '</p>';
            echo '<p class="option">Option C: ' . $row["optionc"] . '</p>';
            echo '<p class="option">Option D: ' . $row["optiond"] . '</p>';
            echo '<p class="correct-answer">Correct Answer: ' . $row["right_ans"] . '</p>';
            echo '<div class="button-container">';
            echo '<form method="post" style="display: inline;">';
            echo '<input type="hidden" name="update_id" value="' . $row["id"] . '">';
            echo '<button type="button" class="btn btn-update" onclick="showUpdateForm(' . $row["id"] . ')">Update</button>';
            echo '</form>';
            echo '<form method="post" style="display: inline;">';
            echo '<input type="hidden" name="delete_id" value="' . $row["id"] . '">';
            echo '<button type="submit" class="btn btn-delete" onclick="return confirm(\'Are you sure you want to delete this question?\')">Delete</button>';
            echo '</form>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
        }
    } else {
        echo '<p class="no-results">No results found.</p>';
    }

    // Close connection
    $conn->close();
    ?>

  </div>

  <script>
    function showUpdateForm(id) {
    // Fetch question details and set as default values in the update form
    var question = document.querySelector('.question:nth-of-type(' + id + ') .question-text:nth-of-type(2)').innerText.split('Question: ')[1];
    var optionA = document.querySelector('.question:nth-of-type(' + id + ') .option:nth-of-type(1)').innerText.split('Option A: ')[1];
    var optionB = document.querySelector('.question:nth-of-type(' + id + ') .option:nth-of-type(2)').innerText.split('Option B: ')[1];
    var optionC = document.querySelector('.question:nth-of-type(' + id + ') .option:nth-of-type(3)').innerText.split('Option C: ')[1];
    var optionD = document.querySelector('.question:nth-of-type(' + id + ') .option:nth-of-type(4)').innerText.split('Option D: ')[1];
    var correctAnswer = document.querySelector('.question:nth-of-type(' + id + ') .correct-answer').innerText.split('Correct Answer: ')[1];
    
    // Set default values in the update form
    document.getElementById('update-id').value = id;
    document.getElementById('updated-question').value = question;
    document.getElementById('updated-optiona').value = optionA;
    document.getElementById('updated-optionb').value = optionB;
    document.getElementById('updated-optionc').value = optionC;
    document.getElementById('updated-optiond').value = optionD;
    document.getElementById('updated-right-ans').value = correctAnswer;

    // Show the update form
    document.getElementById('update-form').style.display = 'block';
}


    function hideUpdateForm() {
        // Hide the update form
        document.getElementById('update-form').style.display = 'none';
    }
    function showAddForm() {
      document.getElementById('add-form').style.display = 'block';
    }

    function hideAddForm() {
      document.getElementById('add-form').style.display = 'none';
    }
  </script>
</body>
</html>
