<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
	<link rel="icon" href="image/logo.jpg" type="image/png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="sidebarcss.css">
	<style>
	<style>
    .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
			justify-content: center;
        }

        .box {
            text-align: center;
            padding: 20px;
            border: 2px solid #0066FF;
            border-radius: 10px;
            background-color: #f9f9f9;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 300px;
            height: 300px;
            overflow: auto; 
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center; 
        }

        .box h3 {
            margin-bottom: 20px;
        }

        .load-content-button {
            background-color: #0066FF;
            color: white;
            padding: 10px 20px;
            margin: 5px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        .load-content-button:hover {
            background-color: #90A4AE;
        }
	</style>
</head>
<body>
<!-- Include header -->
<?php include 'header.html'; ?>
<!-- Include navigation bar -->
<?php include 'newnavigation.html'; ?>

<div class="container">
    <div class="sidebar">
        <h2>Admin Dashboard</h2>
        <ul>
            <li><a href="#" onclick="loadContent('reg.php')"><i class="fas fa-user-plus"></i>Register members</a></li>
            <li><a href="#" onclick="loadContent('schedule.php')"><i class="fas fa-calendar-alt"></i>Schedule exam</a></li>
            <!--li><a href="#" onclick="loadContent('add_que_bank.php')"><i class="fas fa-book"></i>Add question bank</a></li>
            <li><a href="#" onclick="loadContent('view_paper.php')"><i class="fas fa-eye"></i>View Papers</a></li>
            <li><a href="#" onclick="loadContent('upload_paper.php')"><i class="fas fa-cloud-upload-alt"></i>Upload Papers</a></li>
            <li><a href="#" onclick="loadContent('result_fac_add.php')"><i class="fas fa-chart-line"></i>Analyze</a></li-->
			<li><a href="#" onclick="loadContent('result_fac_add.php')"><i class="fas fa-chart-bar"></i>View Result</a>
			<li><a href="new_logout_admin.php" ><i class="fas fa-sign-out-alt"></i>Logout</a>
            
            
        </ul>
    </div>
    <div class="content" id="content">
        <!-- Content will be loaded dynamically here -->
		<div class="container">
  <!--  <div class="box">
        <h3>Register Members</h3>
        <button class="load-content-button" onclick="loadContent('register_faculty.php')">Faculty Registration</button>
        <button class="load-content-button" onclick="loadContent('register_student.php')">Student Registration</button>
    </div> -->
</div>
    </div>
</div>

<script src="sidebarjs.js"></script>

<script>
    function loadContent(page) {
        var contentDiv = document.getElementById("content");
        if (page === 'reg.php') {
            // Load content for Member Registration
            contentDiv.innerHTML = `
                <div class="content" id="content">
        <!-- Content will be loaded dynamically here -->
		<div class="container">
    <div class="box">
        <h3>Register Members</h3>
        <button class="load-content-button" onclick="loadContent('register_faculty.php')">Faculty Registration</button>
        <button class="load-content-button" onclick="loadContent('register_student.php')">Student Registration</button>
    </div>
</div>
            `;
        } else {
            // Load content for other pages
            contentDiv.innerHTML = '<iframe src="' + page + '" width="100%" height="100%" frameborder="0"></iframe>';
        }
    }
</script>

<!-- Include footer -->
<?php include 'footer.html'; ?>
</body>
</html>
