<?php
// Connect to the database
$conn = new mysqli('localhost', 'root', '', 'examination');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to select username, score, and date from exam_result table
$query = "SELECT email, score, date, percentage FROM result_table";

// Execute the query
$result = $conn->query($query);

// Check if there are any rows returned
if ($result->num_rows > 0) {
    // Define CSV filename
    $filename = "exam_results.csv";

    // Set headers for CSV download
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '"');

    // Open file pointer
    $fp = fopen('php://output', 'w');

    // Add CSV headers
    fputcsv($fp, array('Email', 'Score', 'Date', 'Percentage'));

    // Output data of each row
    while ($row = $result->fetch_assoc()) {
        fputcsv($fp, $row);
    }

    // Close file pointer
    fclose($fp);
} else {
    echo "0 results";
}

// Close the database connection
$conn->close();
?>
