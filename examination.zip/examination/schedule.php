<?php
session_start();

// Sample array representing semesters for each year
$semesters = array(
    '1' => array('1', '2'),
    '2' => array('3', '4'),
    '3' => array('5', '6'),
);

// Sample array representing courses for each semester for each year
$courses = array(
    '1' => array(
        '1' => array('ICOA', 'Programming Using C'),
        '2' => array('Programming Using C++', 'Operating System With UNIX'),
    ),
    '2' => array(
        '3' => array('Data Structure', 'Programming Using JAVA'),
        '4' => array('Programming Using Python', 'Internet Of Things'),
    ),
    '3' => array(
        '5' => array('Computer Graphics', 'Web Development Using PHP'),
        '6' => array('Cyber Security', 'Digital Marketing'),
    ),
);

$selectedYear = isset($_POST['year']) ? $_POST['year'] : '';
$selectedSemester = isset($_POST['sem']) ? $_POST['sem'] : '';
$selectedCourse = isset($_POST['course']) ? $_POST['course'] : '';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam Schedule</title>
	<link rel="icon" href="image/logo.jpg" type="image/png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
	 <style>
        /* Additional CSS for form styling */
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: #4e7ab8;
            color: #fff;
            border-radius: 10px 10px 0 0;
        }

        .form-group label {
            font-weight: bold;
            color: #333;
        }

        .btn-primary {
            background-color: #4e7ab8;
            border: none;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        input[type="datetime-local"],
        select.form-control {
            border: 1px solid #ced4da;
            border-radius: 5px;
            padding: 0.375rem 0.75rem;
            font-size: 1rem;
            line-height: 1.5;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <?php
            if (isset($_SESSION['status'])) {
                ?>
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <?php echo $_SESSION['status']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php
                unset($_SESSION['status']);
            }
            ?>
            <div class="card mt-5">
                <div class="card-header">
                    <h4>Exam Schedule</h4>
                </div>
                <div class="card-body">
                    <form method="post" action="store_data_shedule.php"> <!--upload_schedule.php-->
						<div class="form-group mb-3">
                            <label for="program">Select sceduleid:</label>
							<input type="text" name="scheduleid" class="form-control">
                        </div>
						
                        <div class="form-group mb-3">
                            <label for="dateandtime">Set Date & Time:</label>
                            <input type="datetime-local" name="date_time" class="form-control">
                        </div>
						
                        <div class="form-group mb-3">
                            <label for="program">Select Program:</label>
                            <select name="program" id="program" class="form-control">
                                <option value="">Select Program</option>
                                <option value="BCA">BCA</option>
								<option value="Msc IT">Msc IT</option>
                            </select>
                        </div>
                        <div class="form-group mb-3">
                            <label for="year">Select Year:</label>
                            <select name="year" id="year" class="form-control" onchange="updateSemesters()">
                                <option value="">Select Year</option>
                                <?php foreach ($semesters as $year => $year_semesters): ?>
                                    <option value="<?php echo $year; ?>"
                                        <?php echo ($selectedYear == $year) ? 'selected' : ''; ?>><?php echo $year; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group mb-3">
                            <label for="semester">Select Semester:</label>
                            <select name="sem" id="semester" class="form-control" onchange="updateCourses()">
                                <option value="">Select Semester</option>
                            </select>
                        </div>
                        <div class="form-group mb-3">
                            <label for="course">Select Course:</label>
                            <select name="course" id="course" class="form-control">
                                <option value="">Select Course</option>
                            </select>
                        </div>
                        <div class="form-group mb-3">
                            <button type="submit" name="submit" class="btn btn-primary">Upload</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    var courses = <?php echo json_encode($courses); ?>;

    function updateSemesters() {
        var yearSelect = document.getElementById("year");
        var semesterSelect = document.getElementById("semester");
        var selectedYear = yearSelect.value;
        semesterSelect.innerHTML = ''; // Clear previous options

        if (selectedYear !== '') {
            var yearSemesters = courses[selectedYear];
            for (var semester in yearSemesters) {
                var option = document.createElement("option");
                option.value = semester;
                option.text = semester;
                semesterSelect.appendChild(option);
            }
            updateCourses(); // Update courses when year changes
        } else {
            var option = document.createElement("option");
            option.text = 'Select Semester';
            semesterSelect.appendChild(option);
        }
    }

    function updateCourses() {
        var yearSelect = document.getElementById("year");
        var semesterSelect = document.getElementById("semester");
        var courseSelect = document.getElementById("course");
        var selectedYear = yearSelect.value;
        var selectedSemester = semesterSelect.value;
        courseSelect.innerHTML = ''; // Clear previous options

        if (selectedYear !== '' && selectedSemester !== '') {
            var semesterCourses = courses[selectedYear][selectedSemester];
            for (var i = 0; i < semesterCourses.length; i++) {
                var option = document.createElement("option");
                option.value = semesterCourses[i];
                option.text = semesterCourses[i];
                courseSelect.appendChild(option);
            }
        } else {
            var option = document.createElement("option");
            option.text = 'Select Course';
            courseSelect.appendChild(option);
        }
    }

    // Initialize the dropdowns
    updateSemesters();
</script>

<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
<!--
<script>
function loadContent(page) {
    var contentDiv = document.getElementById("content");
    if (page === 'slider.html') {
        // Load content for Faculty
        contentDiv.innerHTML = `
            <button onclick="loadContent('faculty_registration.html')">Faculty Registration</button>
            <button onclick="loadContent('student_registration.html')">Student Registration</button>
        `;
    } else {
        // Load content for other pages
        contentDiv.innerHTML = '<iframe src="' + page + '" width="100%" height="100%" frameborder="0"></iframe>';
    }
}
 </script>
 -->
 
</body>
</html>
