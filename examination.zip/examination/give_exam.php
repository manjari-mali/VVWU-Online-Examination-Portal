<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Information</title>
	<link rel="icon" href="image/logo.jpg" type="image/png">
    <style>
        /* General styles */
      body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
        }

        /* Container to center boxes */
        .container {
            max-width: 800px;
            margin: 0 auto;
            text-align: center;
        }

        /* Styles for info-box */
        .info-box {
            background-color: #ffffff;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            max-width: 400px; /* Adjust the maximum width as needed */
            width: 100%; /* Ensure responsiveness */
            display: inline-block; /* Ensure inline-block elements can be centered */
            text-align: left; /* Reset text-align */
        }

        .info-box p {
            margin: 5px 0;
            font-size: 18px;
            color: #333333; /* Text color */
        }

        /* Styles for course-box */
        .course-box {
            background-color: #ffffff;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            max-width: 400px; /* Adjust the maximum width as needed */
            width: 100%; /* Ensure responsiveness */
            display: inline-block; /* Ensure inline-block elements can be centered */
            text-align: left; /* Reset text-align */
        }

        .course-box h3 {
            margin-top: 0;
            font-size: 24px;
            color: #333333; /* Text color */
            margin-bottom: 15px; /* Add some spacing */
        }

        .course-box p {
            margin: 10px 0;
            font-size: 16px;
            color: #555555; /* Text color */
        }

        .course-box a {
            color: #007bff; /* Link color */
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .course-box a:hover {
            color: #0056b3; /* Hover color */
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="container">
    <?php
    if (isset($_SESSION['email'])) {
      $email = $_SESSION['email'];
      $conn = new mysqli('localhost', 'root', '', 'examination');

      // Check connection
      if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
      }

      // Sanitize email input (important!)
      $sanitized_email = $conn->real_escape_string($email);

      $sql = "SELECT program, year, sem FROM reg_stu WHERE email='$sanitized_email'";
      $result = $conn->query($sql);

      if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Display the user information
        echo "<div class='info-box'>";
        echo "<p><strong>Program:</strong> {$user['program']}</p>";
        echo "<p><strong>Year:</strong> {$user['year']}</p>";
        echo "<p><strong>Semester:</strong> {$user['sem']}</p>";
        echo "</div>"; // End info-box

        // Store semester in a descriptive variable
        $userSemester = $user['sem'];

        // Fetch and display courses
        $course_sql = "SELECT course FROM cour WHERE sem='$userSemester'";
        $course_result = $conn->query($course_sql);

        if ($course_result->num_rows > 0) {
          echo "<div class='course-box'>";
          echo "<h3>Courses for Semester $userSemester:</h3>";
          while ($course_row = $course_result->fetch_assoc()) {
            // Make each course clickable
            echo "<p>Course: <a href='fetch_exam.php?course=" . urlencode($course_row['course']) . "'>" . $course_row['course'] . "</a></p>";
          }
          echo "</div>"; // End course-box
        } else {
          echo "<div class='course-box'>";
          echo "<p>No courses found for Semester $userSemester.</p>";
          echo "</div>"; // End course-box
        }
      } else {
        echo "No user found.";
      }

      $conn->close();
    } else {
      echo "Please <a href='login.php'>login</a> to view your information.";
    }
    ?>
</div>
</body>
</html>
