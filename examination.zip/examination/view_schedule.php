<!--
<style>
    table {
        width: 100%;
        border-collapse: collapse;
        border: 1px solid black; /* Add border to the table */
    }
	th, td {
        padding: 8px;
        text-align: left;
        border-bottom: 1px solid black;
    }
</style> -->
<style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f3f3f3;
            margin: 0;
            padding: 0;
        }

        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: #fff;
        }

        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
            border-right: 1px solid #ddd; /* Add right border to create partitions */
            color: #555; /* Change text color */
        }

        th:last-child,
        td:last-child {
            border-right: none; /* Remove right border for the last column */
        }

        th {
            background-color: #4e7ab8; /* Dark red background */
            color: #fff; /* White text color */
            font-weight: bold;
            text-transform: uppercase;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }
    </style>
    <?php
    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "examination";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch data from database
    $sql = "SELECT * FROM schedule_exam";
    $result = $conn->query($sql);
	

    if ($result->num_rows > 0) {
        echo "<table>";
        echo "<tr><th>Schedule Id</th><th>Date & Time</th><th>Program</th><th>Year</th><th>Semester</th><th>Course</th></tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr><td>".$row["scheduleid"]."</td><td>".$row["date_time"]."</td><td>".$row["program"]."</td><td>".$row["year"]."</td><td>".$row["sem"]."</td><td>".$row["course"]."</td></tr>";
        }
        echo "</table>";
    } else {
        echo "No exams scheduled.";
    }
    $conn->close();
    ?>

