<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Examination Portal</title>
	<link rel="icon" href="image/logo.jpg" type="image/png">
    <link rel="stylesheet" href="styles.css">
    <style>
    main {
	  position: relative; 
	  background-image: url('image/bg_con.jpg'); /* Replace 'path/to/your/image.jpg' with the path to your image */
	  background-size: cover; /* Adjusts the size of the background image to cover the entire element */
	  background-position: center; /* Centers the background image */
	  
	  
	}
	.main-content {
		display: flex;
		justify-content: space-between;
		padding: 40px;
	}

	.left-section,
	.right-section {
		flex-basis: 45%; /* Adjust as needed */
	}
	.contact_css{
		text-align: right;
	}
	.contactus_css{
		text-align: left;
	}

	.left-section {
		text-align: center;
	}

	.right-section {
		text-align: center;
	}

	.main-content img {
		max-width: 100%;
		height: auto;
	}

    </style>
	<!-- Include header -->
    <?php include 'header.html'; ?>
</head>
<body>
     <!-- Include navbar -->
    <?php include 'navigation.html'; ?>
<main>
<section class="main-content">
 <div class="right-section">
       
        <div class="contactus_css">
            <h3>Vanita Vishram Head Office Mumbai</h3>
            <p><img src="image/icon_location.png" height="15px" width="15px">  Reg. No. E/568 (Bom)</p>
            <p>    392, Sardar Vallabhbhai Patel Road,</p>
            <p>Mumbai - 400 004.</p>
            <p><img src="image/icon_call.png" height="15px" width="15px">  Tel: (022) 23851644, </p>
            <p>(022) 23873932</p>
            <p><img src="image/icon_contact.png" height="15px" width="15px">   E-mail: vanitavishramho@gmail.com</p>
            <p><img src="image/icon_location.png" height="15px" width="15px">  Vanita Vishram, Athwa Gate, SURAT – </p>
            <p>395 001 GUJARAT INDIA</p>  
             <h3>Admin Office:</h3>
            <p><img src="image/icon_call.png" height="15px" width="15px">  +91 261 230 0290</p>
            <h3>Inquiry:</h3>
            <p><img src="image/icon_call.png" height="15px" width="15px"> 97277 69044</p>
            <p><img src="image/icon_contact.png" height="15px" width="15px">   office@vvwusurat.ac.in</p>         
        </div>
    </div>
 </main>  
</section>
     <!-- Include footer -->
    <?php include 'footer.html'; ?>
    <script>
        // JavaScript code to handle button click event and redirect
        document.querySelector(".get-started-btn").addEventListener("click", function() {
            // Redirect to the new page
            window.location.href = "newhome.html";
        });
    </script>
</body>
</html>
