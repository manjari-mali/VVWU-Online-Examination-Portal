-- phpMyAdmin SQL Dump
-- version 2.11.2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 28, 2024 at 03:22 PM
-- Server version: 5.0.45
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `vvwu_portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `cour`
--

CREATE TABLE `cour` (
  `courseid` int(11) NOT NULL,
  `courseco` varchar(255) default NULL,
  `course` varchar(255) default NULL,
  `sem` varchar(255) default NULL,
  `year` int(11) default NULL,
  `program` varchar(255) default NULL,
  PRIMARY KEY  (`courseid`),
  UNIQUE KEY `courseco` (`courseco`),
  UNIQUE KEY `course` (`course`),
  KEY `sem` (`sem`),
  KEY `year` (`year`),
  KEY `program` (`program`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cour`
--

INSERT INTO `cour` (`courseid`, `courseco`, `course`, `sem`, `year`, `program`) VALUES
(1, 'CS11070-Operating System With UNIX', 'Operating System With UNIX', '2', 1, 'BCA'),
(2, 'CS11010-ICOA', 'ICOA', '1', 1, 'BCA'),
(3, 'CS11030-Programming Using C', 'Programming Using C', '1', 1, 'BCA'),
(4, 'CS11050-Programming Using C++', 'Programming Using C++', '2', 1, 'BCA'),
(5, 'CS11090-Data Structure', 'Data Structure', '3', 2, 'BCA'),
(6, 'CS11130-Programming Using JAVA', 'Programming Using JAVA', '3', 2, 'BCA'),
(7, 'CS11160-Programming Using Python', 'Programming Using Python', '4', 2, 'BCA'),
(8, 'CS51020-Internet Of Things', 'Internet Of Things', '4', 2, 'BCA'),
(9, 'CS11210-Computer Graphics', 'Computer Graphics', '5', 3, 'BCA'),
(10, 'CS11220-Web Development Using PHP', 'Web Development Using PHP', '5', 3, 'BCA'),
(11, 'CS14090-Cyber Security', 'Cyber Security', '6', 3, 'BCA'),
(12, 'CS14110-Digital Marketing', 'Digital Marketing', '6', 3, 'BCA');

-- --------------------------------------------------------

--
-- Table structure for table `exam_result`
--

CREATE TABLE `exam_result` (
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `course` varchar(255) NOT NULL,
  `exam_date_time` varchar(255) NOT NULL,
  `score` varchar(255) NOT NULL,
  `sem` varchar(255) NOT NULL,
  `year` varchar(255) NOT NULL,
  `program` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_result`
--

INSERT INTO `exam_result` (`username`, `email`, `course`, `exam_date_time`, `score`, `sem`, `year`, `program`, `date`, `time`) VALUES
('2112186.manjari.mali@vvwusurat.ac.in', '2112186.manjari.mali@vvwusurat.ac.in', '', '', '40', '', '', '', '2024-03-27', '14:00:57'),
('2112186.manjari.mali@vvwusurat.ac.in', '2112186.manjari.mali@vvwusurat.ac.in', '', '', '60', '', '', '', '2024-03-27', '14:05:47'),
('2112186.manjari.mali@vvwusurat.ac.in', '2112186.manjari.mali@vvwusurat.ac.in', '', '', '30', '', '', '', '2024-03-27', '14:08:41');

-- --------------------------------------------------------

--
-- Table structure for table `generate_paper`
--

CREATE TABLE `generate_paper` (
  `paper_id` int(11) NOT NULL,
  `date_time` datetime default NULL,
  `courseco` varchar(255) default NULL,
  `courseid` int(11) default NULL,
  PRIMARY KEY  (`paper_id`),
  KEY `courseco` (`courseco`),
  KEY `courseid` (`courseid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `generate_paper`
--


-- --------------------------------------------------------

--
-- Table structure for table `give_exam`
--

CREATE TABLE `give_exam` (
  `exstuid` int(11) NOT NULL,
  `paperid` int(11) default NULL,
  `rollno` int(11) default NULL,
  `que` varchar(255) default NULL,
  `optiona` varchar(255) default NULL,
  `optionb` varchar(255) default NULL,
  `optionc` varchar(255) default NULL,
  `optiond` varchar(255) default NULL,
  `select_ans` varchar(1) default NULL,
  PRIMARY KEY  (`exstuid`),
  KEY `paperid` (`paperid`),
  KEY `rollno` (`rollno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `give_exam`
--


-- --------------------------------------------------------

--
-- Table structure for table `login_adm`
--

CREATE TABLE `login_adm` (
  `username` varchar(255) default NULL,
  `password` varchar(255) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_adm`
--


-- --------------------------------------------------------

--
-- Table structure for table `login_fac`
--

CREATE TABLE `login_fac` (
  `username` varchar(255) default NULL,
  `password` varchar(255) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_fac`
--


-- --------------------------------------------------------

--
-- Table structure for table `login_stu`
--

CREATE TABLE `login_stu` (
  `email` varchar(255) default NULL,
  `password` varchar(255) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_stu`
--


-- --------------------------------------------------------

--
-- Table structure for table `pro`
--

CREATE TABLE `pro` (
  `pid` int(11) NOT NULL,
  `program` varchar(255) default NULL,
  `dept` varchar(255) default NULL,
  PRIMARY KEY  (`pid`),
  UNIQUE KEY `program` (`program`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pro`
--

INSERT INTO `pro` (`pid`, `program`, `dept`) VALUES
(1, 'BCA', 'Science and Technology');

-- --------------------------------------------------------

--
-- Table structure for table `qbc10`
--

CREATE TABLE `qbc10` (
  `id` int(11) NOT NULL,
  `courseid` int(11) default NULL,
  `que` varchar(255) default NULL,
  `optiona` varchar(255) default NULL,
  `optionb` varchar(255) default NULL,
  `optionc` varchar(255) default NULL,
  `optiond` varchar(255) default NULL,
  `right_ans` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `courseid` (`courseid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qbc10`
--


-- --------------------------------------------------------

--
-- Table structure for table `qbc11`
--

CREATE TABLE `qbc11` (
  `id` int(11) NOT NULL,
  `courseid` int(11) default NULL,
  `que` varchar(255) default NULL,
  `optiona` varchar(255) default NULL,
  `optionb` varchar(255) default NULL,
  `optionc` varchar(255) default NULL,
  `optiond` varchar(255) default NULL,
  `right_ans` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `courseid` (`courseid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qbc11`
--

INSERT INTO `qbc11` (`id`, `courseid`, `que`, `optiona`, `optionb`, `optionc`, `optiond`, `right_ans`) VALUES
(1, 11, 'What does VPN stand for?', 'Virtual Personal Network', 'Virtual Private Network', 'Virtual Protected Network', 'Virtual Public Network', 'optionb'),
(2, 11, 'What is the primary purpose of a firewall in network security?', 'To detect and remove malware', 'To prevent unauthorized access', 'To encrypt network traffic', 'To monitor network performance', 'optionb'),
(3, 11, 'Which of the following is NOT considered a strong password?', 'Password123', '[email protected]', 'P@ssw0rd!', 'Tr0ub4dor&3', 'optiona'),
(4, 11, 'What is the purpose of encryption in data security?', 'To compress data', 'To hide data', 'To secure data', 'To authenticate data', 'optionc'),
(5, 11, 'What is the main objective of phishing attacks?', 'To steal sensitive information', 'To spread viruses', 'To overload a server', 'To disable network services', 'optiona'),
(6, 11, 'Which of the following is NOT a type of malware?', 'Virus', 'Trojan', 'Spyware', 'Firewall', 'optiond'),
(7, 11, 'What is the purpose of biometric authentication?', 'To use a physical token for authentication', 'To verify identity based on unique biological traits', 'To use a password for authentication', 'To verify identity based on social media profiles', 'optionb'),
(8, 11, 'Which protocol is commonly used for secure communication over the internet?', 'HTTP', 'FTP', 'SMTP', 'HTTPS', 'optiond'),
(9, 11, 'What is the main purpose of a vulnerability assessment?', 'To simulate cyber attacks', 'To identify security weaknesses', 'To encrypt sensitive data', 'To monitor network traffic', 'optionb'),
(10, 11, 'What is a DDoS attack?', 'Distributed Denial of Security', 'Decentralized Denial of Service', 'Distributed Denial of Service', 'Decentralized Denial of Security', 'optionc'),
(11, 11, 'What is the purpose of a security patch?', 'To fix security vulnerabilities', 'To enhance system performance', 'To upgrade hardware components', 'To optimize network bandwidth', 'optiona'),
(12, 11, 'What is the primary goal of network segmentation?', 'To isolate sensitive data', 'To increase network speed', 'To reduce network complexity', 'To improve data encryption', 'optiona'),
(13, 11, 'Which of the following is NOT a common cyber attack vector?', 'Email attachments', 'Social media profiles', 'Malicious websites', 'USB devices', 'optionb'),
(14, 11, 'What is the purpose of multi-factor authentication (MFA)?', 'To use multiple passwords for authentication', 'To verify identity using multiple methods', 'To create multiple user accounts', 'To encrypt multiple files simultaneously', 'optionb'),
(15, 11, 'What does the term "phishing" refer to in cyber security?', 'Sending unsolicited emails', 'Stealing credit card information', 'Social engineering attacks', 'Spoofing IP addresses', 'optionc'),
(16, 11, 'Which encryption algorithm is commonly used for secure email communication?', 'AES', 'RSA', 'DES', 'SHA', 'optionb'),
(17, 11, 'What is the purpose of a security incident response plan?', 'To prevent security incidents', 'To respond effectively to security breaches', 'To create secure passwords', 'To encrypt sensitive data', 'optionb'),
(18, 11, 'What is the primary function of an intrusion detection system (IDS)?', 'To prevent unauthorized access', 'To monitor network traffic', 'To encrypt data transmissions', 'To authenticate users', 'optionb'),
(19, 11, 'Which of the following is a common authentication factor?', 'Something you know', 'Something you have', 'Something you are', 'All of the above', 'optiond'),
(20, 11, 'What is the purpose of a security policy?', 'To ensure compliance with legal regulations', 'To define rules and guidelines for security measures', 'To restrict access to sensitive data', 'To enhance network performance', 'optionb');

-- --------------------------------------------------------

--
-- Table structure for table `qbc12`
--

CREATE TABLE `qbc12` (
  `id` int(11) NOT NULL,
  `courseid` int(11) default NULL,
  `que` varchar(255) default NULL,
  `optiona` varchar(255) default NULL,
  `optionb` varchar(255) default NULL,
  `optionc` varchar(255) default NULL,
  `optiond` varchar(255) default NULL,
  `right_ans` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `courseid` (`courseid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qbc12`
--


-- --------------------------------------------------------

--
-- Table structure for table `qbco1`
--

CREATE TABLE `qbco1` (
  `id` int(11) NOT NULL,
  `courseid` int(11) default NULL,
  `que` varchar(255) default NULL,
  `optiona` varchar(255) default NULL,
  `optionb` varchar(255) default NULL,
  `optionc` varchar(255) default NULL,
  `optiond` varchar(255) default NULL,
  `right_ans` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `courseid` (`courseid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qbco1`
--


-- --------------------------------------------------------

--
-- Table structure for table `qbco2`
--

CREATE TABLE `qbco2` (
  `id` int(11) NOT NULL,
  `courseid` int(11) default NULL,
  `que` varchar(255) default NULL,
  `optiona` varchar(255) default NULL,
  `optionb` varchar(255) default NULL,
  `optionc` varchar(255) default NULL,
  `optiond` varchar(255) default NULL,
  `right_ans` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `courseid` (`courseid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qbco2`
--


-- --------------------------------------------------------

--
-- Table structure for table `qbco3`
--

CREATE TABLE `qbco3` (
  `id` int(11) NOT NULL,
  `courseid` int(11) default NULL,
  `que` varchar(255) default NULL,
  `optiona` varchar(255) default NULL,
  `optionb` varchar(255) default NULL,
  `optionc` varchar(255) default NULL,
  `optiond` varchar(255) default NULL,
  `right_ans` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `courseid` (`courseid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qbco3`
--

INSERT INTO `qbco3` (`id`, `courseid`, `que`, `optiona`, `optionb`, `optionc`, `optiond`, `right_ans`) VALUES
(1, 4, 'What is the output of the following code snippet? int x = 5; int y = ++x + x++; cout << y;', '10', '11', '12', '13', 'optiond'),
(2, 4, 'Which keyword is used to define a class in C++?', 'class', 'struct', 'def', 'interface', 'optiona'),
(3, 4, 'Which operator is used to access the member functions and variables of an object in C++?', '.', '->', '::', '<>', 'optiona'),
(4, 4, 'What is the output of the following code snippet? int arr[5] = {1, 2, 3, 4, 5}; cout << arr[6];', '0', '1', 'Garbage value', 'Compilation error', 'optiond'),
(5, 4, 'What is the correct way to declare a pointer in C++?', 'pointer int x;', 'int *x;', 'x = &int;', 'int &x;', 'optionb');

-- --------------------------------------------------------

--
-- Table structure for table `qbco4`
--

CREATE TABLE `qbco4` (
  `id` int(11) NOT NULL,
  `courseid` int(11) default NULL,
  `que` varchar(255) default NULL,
  `optiona` varchar(255) default NULL,
  `optionb` varchar(255) default NULL,
  `optionc` varchar(255) default NULL,
  `optiond` varchar(255) default NULL,
  `right_ans` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `courseid` (`courseid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qbco4`
--

INSERT INTO `qbco4` (`id`, `courseid`, `que`, `optiona`, `optionb`, `optionc`, `optiond`, `right_ans`) VALUES
(1, 1, 'Which operating system is based on the UNIX architecture?', 'Linux', 'Windows', 'macOS', 'Android', 'optiona'),
(2, 1, 'What is the primary function of an operating system?', 'Managing hardware resources', 'Providing entertainment', 'Running applications', 'Sending emails', 'optiona'),
(3, 1, 'Which command is used to display the current directory in UNIX?', 'dir', 'cd', 'ls', 'pwd', 'optiond'),
(4, 1, 'What does the ''grep'' command do in UNIX?', 'Search for files', 'Display calendar', 'Search for text patterns in files', 'Print file contents', 'optionc'),
(5, 1, 'Which file system is commonly used in UNIX-based operating systems?', 'NTFS', 'FAT32', 'ext4', 'FAT16', 'optionc'),
(6, 1, 'Which command is used to create a new directory in UNIX?', 'newdir', 'mkdir', 'createdir', 'makedir', 'optionb'),
(7, 1, 'What is the purpose of the ''chmod'' command in UNIX?', 'Change file ownership', 'Change file ownership', 'Change file ownership', 'Change file ownership', 'optionb'),
(8, 1, 'Which UNIX command is used to display the contents of a file?', 'print', 'cat', 'show', 'view', 'optionb'),
(9, 1, 'What does the ''grep'' command stand for in UNIX?', 'Global regular expression print', 'General regular expression program', 'Global regular expression program', 'General regular expression print', 'optionc'),
(10, 1, 'Which command is used to remove a file in UNIX?', 'rm', 'del', 'remove', 'delete', 'optiona'),
(11, 1, 'What is the purpose of the ''tar'' command in UNIX?', 'Create a new file', 'Extract files from an archive', 'Compress files into an archive', 'Encrypt files', 'optionc'),
(12, 1, 'Which UNIX command is used to change the current directory?', 'dir', 'chdir', 'cd', 'changedir', 'optionc'),
(13, 1, 'Which command is used to display the manual page for a UNIX command?', 'info', 'help', 'man', 'manual', 'optionc'),
(14, 1, 'What does the ''ps'' command do in UNIX?', 'Print system information', 'Display current processes', 'Pause system operation', 'Pause system operation', 'optionb'),
(15, 1, 'Which command is used to display the disk usage in UNIX?', 'du', 'df', 'disk', 'usage', 'optiona'),
(16, 1, 'What is the purpose of the ''passwd'' command in UNIX?', 'Print user passwords', 'Change user password', 'Delete user password', 'View user password policy', 'optionb'),
(17, 1, 'Which command is used to create a symbolic link in UNIX?', 'ln', 'link', 'symlink', 'mklink', 'optiona'),
(18, 1, 'What does the ''top'' command do in UNIX?', 'Display system hardware information', 'Display running processes and their resource usage', '. Display disk space usage', '. Display disk space usage', 'optionb'),
(19, 1, 'Which command is used to terminate a process in UNIX?', 'kill', 'stop', 'end', 'terminate', 'optiona'),
(20, 1, 'What does the ''grep -v'' command do in UNIX?', 'Display verbose output', 'Display verbose output', 'Display only filenames', 'Display version information', 'optionb');

-- --------------------------------------------------------

--
-- Table structure for table `qbco5`
--

CREATE TABLE `qbco5` (
  `id` int(11) NOT NULL,
  `courseid` int(11) default NULL,
  `que` varchar(255) default NULL,
  `optiona` varchar(255) default NULL,
  `optionb` varchar(255) default NULL,
  `optionc` varchar(255) default NULL,
  `optiond` varchar(255) default NULL,
  `right_ans` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `courseid` (`courseid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qbco5`
--


-- --------------------------------------------------------

--
-- Table structure for table `qbco6`
--

CREATE TABLE `qbco6` (
  `id` int(11) NOT NULL,
  `courseid` int(11) default NULL,
  `que` varchar(255) default NULL,
  `optiona` varchar(255) default NULL,
  `optionb` varchar(255) default NULL,
  `optionc` varchar(255) default NULL,
  `optiond` varchar(255) default NULL,
  `right_ans` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `courseid` (`courseid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qbco6`
--


-- --------------------------------------------------------

--
-- Table structure for table `qbco7`
--

CREATE TABLE `qbco7` (
  `id` int(11) NOT NULL,
  `courseid` int(11) default NULL,
  `que` varchar(255) default NULL,
  `optiona` varchar(255) default NULL,
  `optionb` varchar(255) default NULL,
  `optionc` varchar(255) default NULL,
  `optiond` varchar(255) default NULL,
  `right_ans` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `courseid` (`courseid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qbco7`
--


-- --------------------------------------------------------

--
-- Table structure for table `qbco8`
--

CREATE TABLE `qbco8` (
  `id` int(11) NOT NULL,
  `courseid` int(11) default NULL,
  `que` varchar(255) default NULL,
  `optiona` varchar(255) default NULL,
  `optionb` varchar(255) default NULL,
  `optionc` varchar(255) default NULL,
  `optiond` varchar(255) default NULL,
  `right_ans` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `courseid` (`courseid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qbco8`
--


-- --------------------------------------------------------

--
-- Table structure for table `qbco9`
--

CREATE TABLE `qbco9` (
  `id` int(11) NOT NULL,
  `courseid` int(11) default NULL,
  `que` varchar(255) default NULL,
  `optiona` varchar(255) default NULL,
  `optionb` varchar(255) default NULL,
  `optionc` varchar(255) default NULL,
  `optiond` varchar(255) default NULL,
  `right_ans` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `courseid` (`courseid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qbco9`
--

INSERT INTO `qbco9` (`id`, `courseid`, `que`, `optiona`, `optionb`, `optionc`, `optiond`, `right_ans`) VALUES
(1, 9, 'Which of the following is NOT a 2D primitive in computer graphics?', 'Line', 'Circle', 'Cube', 'Polygon', 'optionc'),
(2, 9, 'What is the purpose of a raster scan display?', 'To produce high-quality images', 'To display images using pixels', 'To display images using pixels', 'To display images using pixels', 'optionb'),
(3, 9, 'What does GPU stand for in computer graphics?', 'Graphics Processing Unit', 'Graphical Pixel Unit', 'Graphical Processing Engine', 'Geometric Processing Unit', 'optiona'),
(4, 9, 'Which algorithm is used for line clipping in computer graphics?', 'Bresenham''s Line Algorithm', 'Cohen-Sutherland Line Clipping Algorithm', 'Midpoint Line Algorithm', 'Liang-Barsky Line Clipping Algorithm', 'optionb'),
(5, 9, 'What is the purpose of anti-aliasing in computer graphics?', 'To reduce the number of polygons in a model', 'To remove jagged edges in rendered images', 'To remove jagged edges in rendered images', 'To improve texture mapping', 'optionb'),
(6, 9, 'Which transformation is used to rotate an object in computer graphics?', 'Translation', 'Scaling', 'Rotation', 'Reflection', 'optionc'),
(7, 9, 'Which rendering technique is based on simulating the behavior of light in a scene?', 'Wireframe rendering', 'Rasterization', 'Ray tracing', 'Texture mapping', 'optionc'),
(8, 9, 'Which 3D primitive is used to represent a sphere in computer graphics?', 'Cylinder', 'Cone', 'Sphere', 'Torus', 'optionc'),
(9, 9, 'What is the primary advantage of using vector graphics over raster graphics?', 'Scalability', 'Realism', 'Color depth', 'File size', 'optiona'),
(10, 9, 'What is the purpose of the Z-buffer in computer graphics?', 'To store color information', 'To perform hidden surface removal', 'To control the intensity of light sources', 'To render transparent objects', 'optionb'),
(11, 9, 'Which curve is used to represent smooth curves in computer graphics?', 'Bezier curve', 'B-spline curve', 'Hermite curve', 'Catmull-Rom curve', 'optiona'),
(12, 9, 'Which type of projection is commonly used in 3D graphics applications?', 'Orthographic projection', 'Isometric projection', 'Perspective projection', 'Parallel projection', 'optionc'),
(13, 9, 'What is the primary goal of texture mapping in computer graphics?', 'To add color to objects', 'To simulate surface detail', 'To remove hidden surfaces', 'To transform objects', 'optionb'),
(14, 9, 'Which algorithm is used for polygon filling in computer graphics?', 'Flood Fill Algorithm', 'Bresenham''s Line Algorithm', 'Cohen-Sutherland Line Clipping Algorithm', 'Midpoint Line Algorithm', 'optiona'),
(15, 9, 'Which technique is used to simulate the effect of light reflection on shiny surfaces?', 'Phong shading', 'Gouraud shading', 'Flat shading', 'Lambertian shading', 'optiona'),
(16, 9, 'What is the primary purpose of a framebuffer in computer graphics?', 'To store pixel data', 'To perform rendering calculations', 'To control the display hardware', 'To generate geometry', 'optiona'),
(17, 9, 'Which algorithm is used for hidden surface removal in computer graphics?', 'Bresenham''s Line Algorithm', 'Cohen-Sutherland Line Clipping Algorithm', 'Painter''s Algorithm', 'Midpoint Line Algorithm', 'optionc'),
(18, 9, 'What does VBO stand for in computer graphics?', 'Vector Buffer Object', 'Vertex Buffer Object', 'Visible Backface Object', 'Viewport Border Object', 'optionb'),
(19, 9, 'Which transformation is used to scale an object in computer graphics?', 'Translation', 'Scaling', 'Rotation', 'Reflection', 'optionb'),
(20, 9, 'What is the primary goal of ray tracing in computer graphics?', 'To perform hidden surface removal', 'To perform hidden surface removal', 'To generate texture coordinates', 'To transform 3D objects', 'optionb');

-- --------------------------------------------------------

--
-- Table structure for table `reg_fac`
--

CREATE TABLE `reg_fac` (
  `facid` int(11) NOT NULL,
  `name` varchar(255) default NULL,
  `email` varchar(255) default NULL,
  `password` varchar(255) NOT NULL,
  `contactno` varchar(10) default NULL,
  `dob` date default NULL,
  `doj` date default NULL,
  `gender` varchar(255) default NULL,
  `program` varchar(255) default NULL,
  `course1` varchar(255) default NULL,
  `course2` varchar(255) default NULL,
  `course3` varchar(255) default NULL,
  `course4` varchar(255) default NULL,
  `profile_pic` varchar(255) NOT NULL,
  PRIMARY KEY  (`facid`),
  KEY `program` (`program`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reg_fac`
--

INSERT INTO `reg_fac` (`facid`, `name`, `email`, `password`, `contactno`, `dob`, `doj`, `gender`, `program`, `course1`, `course2`, `course3`, `course4`, `profile_pic`) VALUES
(1, 'Dr. Nirali Dave', '2112186.manjari.mali@vvwusurat.ac.in', 'dr.nirali.dave', '1234567890', '1980-03-01', '2020-08-18', 'Female', 'BCA', 'CS11010-ICOA', 'CS11070-Operating System With UNIX', 'CS11090-Data Structure', 'CS11210-Computer Graphics', 'uploads/girl.jpeg'),
(2, 'Dr.Hemangini Patel', '2112106.maitry.gothi@vvwusurat.ac.in', 'maitry', '9824476295', '1980-06-25', '2022-06-05', 'female', 'BCA', 'CS11030-Programming Using C', 'CS11130-Programming Using JAVA', 'CS11210-Computer Graphics', 'CS14090-Cyber Security', 'uploads/girl.jpeg'),
(3, 'Dr.Dikshan Shah', 'dr.dikshan.shah@vvwusurat.ac.in', 'dikshan.shah', '9824476295', '1985-09-20', '2021-12-15', 'male', 'BCA', 'CS11050-Programming Using C++', 'CS51020-Internet Of Things', 'CS11220-Web Development Using PHP', 'CS11160-Programming Using Python', 'uploads/abc.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `reg_stu`
--

CREATE TABLE `reg_stu` (
  `rollno` int(11) NOT NULL,
  `name` varchar(255) default NULL,
  `email` varchar(255) default NULL,
  `password` varchar(255) NOT NULL,
  `contactno` varchar(10) default NULL,
  `dob` date default NULL,
  `program` varchar(255) default NULL,
  `year` int(11) default NULL,
  `sem` varchar(255) default NULL,
  `div` varchar(255) default NULL,
  `profile_pic` varchar(255) default NULL,
  PRIMARY KEY  (`rollno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reg_stu`
--

INSERT INTO `reg_stu` (`rollno`, `name`, `email`, `password`, `contactno`, `dob`, `program`, `year`, `sem`, `div`, `profile_pic`) VALUES
(2112100, 'Manjari Mali', '2112186.manjari.mali@vvwusurat.ac.in', 'manjari', '9824476295', '2004-04-03', 'BCA', 1, '2', 'B', 'uploads/girl.jpeg'),
(2112101, 'Maitry Gothi', '2112106.maitry.gothi@vvwusurat.ac.in', 'maitrygothi', '9974827803', '2003-08-27', 'BCA', 2, '3', 'A', 'uploads/maitry.jpeg'),
(2112103, 'Maitry Gothi', '2112107.maitry.gothi@vvwusurat.ac.in', '123456', '9974827803', '2004-09-23', 'BCA', 1, '2', 'A', 'uploads/maitry.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `resultid` int(11) NOT NULL,
  `rollno` int(11) default NULL,
  `paperid` int(11) default NULL,
  `right_ans` int(11) default NULL,
  `wrong_ans` int(11) default NULL,
  `obtain_mark` int(11) default NULL,
  PRIMARY KEY  (`resultid`),
  KEY `rollno` (`rollno`),
  KEY `paperid` (`paperid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `result`
--


-- --------------------------------------------------------

--
-- Table structure for table `result_table`
--

CREATE TABLE `result_table` (
  `email` varchar(255) NOT NULL,
  `score` varchar(255) NOT NULL,
  `percentage` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `result_table`
--

INSERT INTO `result_table` (`email`, `score`, `percentage`, `date`, `time`) VALUES
('2112186.manjari.mali@vvwusurat.ac.in', '2', '20', '2024-03-28', '03:18:06'),
('2112107.maitry.gothi@vvwusurat.ac.in', '2', '20', '2024-03-28', '03:34:41'),
('2112186.manjari.mali@vvwusurat.ac.in', '2', '20', '2024-03-28', '04:36:28'),
('2112186.manjari.mali@vvwusurat.ac.in', '3', '30', '2024-03-28', '05:07:07'),
('2112107.maitry.gothi@vvwusurat.ac.in', '2', '20', '2024-03-28', '05:08:03'),
('2112107.maitry.gothi@vvwusurat.ac.in', '10', '100', '2024-03-28', '05:18:03');

-- --------------------------------------------------------

--
-- Table structure for table `schedule_exam`
--

CREATE TABLE `schedule_exam` (
  `scheduleid` int(11) NOT NULL auto_increment,
  `date_time` datetime default NULL,
  `program` varchar(255) default NULL,
  `year` int(11) default NULL,
  `sem` varchar(255) default NULL,
  `course` varchar(255) default NULL,
  PRIMARY KEY  (`scheduleid`),
  UNIQUE KEY `date_time` (`date_time`),
  KEY `program` (`program`),
  KEY `year` (`year`),
  KEY `sem` (`sem`),
  KEY `course` (`course`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `schedule_exam`
--

INSERT INTO `schedule_exam` (`scheduleid`, `date_time`, `program`, `year`, `sem`, `course`) VALUES
(1, '2024-03-25 12:54:00', 'BCA', 1, '2', 'Operating System With UNIX');

-- --------------------------------------------------------

--
-- Table structure for table `semester`
--

CREATE TABLE `semester` (
  `semid` int(11) NOT NULL,
  `sem` varchar(255) default NULL,
  `year` int(11) default NULL,
  `program` varchar(255) default NULL,
  PRIMARY KEY  (`semid`),
  UNIQUE KEY `sem` (`sem`),
  KEY `year` (`year`),
  KEY `program` (`program`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `semester`
--

INSERT INTO `semester` (`semid`, `sem`, `year`, `program`) VALUES
(1, '2', 1, 'BCA'),
(2, '1', 1, 'BCA'),
(3, '3', 2, 'BCA'),
(4, '4', 2, 'BCA'),
(5, '5', 3, 'BCA'),
(6, '6', 3, 'BCA');

-- --------------------------------------------------------

--
-- Table structure for table `store_paper`
--

CREATE TABLE `store_paper` (
  `storeid` int(11) NOT NULL,
  `paperid` int(11) default NULL,
  `id` int(11) default NULL,
  `que` varchar(255) default NULL,
  `optiona` varchar(255) default NULL,
  `optionb` varchar(255) default NULL,
  `optionc` varchar(255) default NULL,
  `optiond` varchar(255) default NULL,
  `right_ans` varchar(1) default NULL,
  PRIMARY KEY  (`storeid`),
  KEY `paperid` (`paperid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `store_paper`
--


-- --------------------------------------------------------

--
-- Table structure for table `tmp_paper`
--

CREATE TABLE `tmp_paper` (
  `id` int(11) NOT NULL auto_increment,
  `subject` varchar(255) NOT NULL,
  `paper` varchar(10000) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37 ;

--
-- Dumping data for table `tmp_paper`
--

INSERT INTO `tmp_paper` (`id`, `subject`, `paper`) VALUES
(34, 'CS11070-Operating System With UNIX', 'Question: 1<br>Which command is used to create a symbolic link in UNIX?<br><input type=''radio'' name=''answer_17'' value=''A''>Option A: ln<br><input type=''radio'' name=''answer_17'' value=''A''>Option B: link<br><input type=''radio'' name=''answer_17'' value=''A''>Option C: symlink<br><input type=''radio'' name=''answer_17'' value=''A''>Option D: mklink<br><br>Question: 2<br>What does the ''grep -v'' command do in UNIX?<br><input type=''radio'' name=''answer_20'' value=''A''>Option A: Display verbose output<br><input type=''radio'' name=''answer_20'' value=''A''>Option B: Display verbose output<br><input type=''radio'' name=''answer_20'' value=''A''>Option C: Display only filenames<br><input type=''radio'' name=''answer_20'' value=''A''>Option D: Display version information<br><br>Question: 3<br>Which UNIX command is used to display the contents of a file?<br><input type=''radio'' name=''answer_8'' value=''A''>Option A: print<br><input type=''radio'' name=''answer_8'' value=''A''>Option B: cat<br><input type=''radio'' name=''answer_8'' value=''A''>Option C: show<br><input type=''radio'' name=''answer_8'' value=''A''>Option D: view<br><br>Question: 4<br>What does the ''top'' command do in UNIX?<br><input type=''radio'' name=''answer_18'' value=''A''>Option A: Display system hardware information<br><input type=''radio'' name=''answer_18'' value=''A''>Option B: Display running processes and their resource usage<br><input type=''radio'' name=''answer_18'' value=''A''>Option C: . Display disk space usage<br><input type=''radio'' name=''answer_18'' value=''A''>Option D: . Display disk space usage<br><br>Question: 5<br>What does the ''ps'' command do in UNIX?<br><input type=''radio'' name=''answer_14'' value=''A''>Option A: Print system information<br><input type=''radio'' name=''answer_14'' value=''A''>Option B: Display current processes<br><input type=''radio'' name=''answer_14'' value=''A''>Option C: Pause system operation<br><input type=''radio'' name=''answer_14'' value=''A''>Option D: Pause system operation<br><br>Question: 6<br>What is the purpose of the ''passwd'' command in UNIX?<br><input type=''radio'' name=''answer_16'' value=''A''>Option A: Print user passwords<br><input type=''radio'' name=''answer_16'' value=''A''>Option B: Change user password<br><input type=''radio'' name=''answer_16'' value=''A''>Option C: Delete user password<br><input type=''radio'' name=''answer_16'' value=''A''>Option D: View user password policy<br><br>Question: 7<br>What is the purpose of the ''tar'' command in UNIX?<br><input type=''radio'' name=''answer_11'' value=''A''>Option A: Create a new file<br><input type=''radio'' name=''answer_11'' value=''A''>Option B: Extract files from an archive<br><input type=''radio'' name=''answer_11'' value=''A''>Option C: Compress files into an archive<br><input type=''radio'' name=''answer_11'' value=''A''>Option D: Encrypt files<br><br>Question: 8<br>What does the ''grep'' command stand for in UNIX?<br><input type=''radio'' name=''answer_9'' value=''A''>Option A: Global regular expression print<br><input type=''radio'' name=''answer_9'' value=''A''>Option B: General regular expression program<br><input type=''radio'' name=''answer_9'' value=''A''>Option C: Global regular expression program<br><input type=''radio'' name=''answer_9'' value=''A''>Option D: General regular expression print<br><br>Question: 9<br>Which operating system is based on the UNIX architecture?<br><input type=''radio'' name=''answer_1'' value=''A''>Option A: Linux<br><input type=''radio'' name=''answer_1'' value=''A''>Option B: Windows<br><input type=''radio'' name=''answer_1'' value=''A''>Option C: macOS<br><input type=''radio'' name=''answer_1'' value=''A''>Option D: Android<br><br>Question: 10<br>What is the purpose of the ''chmod'' command in UNIX?<br><input type=''radio'' name=''answer_7'' value=''A''>Option A: Change file ownership<br><input type=''radio'' name=''answer_7'' value=''A''>Option B: Change file ownership<br><input type=''radio'' name=''answer_7'' value=''A''>Option C: Change file ownership<br><input type=''radio'' name=''answer_7'' value=''A''>Option D: Change file ownership<br><br>'),
(35, 'CS11070-Operating System With UNIX', 'Question: 1<br>What does the ''grep -v'' command do in UNIX?<br><input type=''radio'' name=''answer_20'' value=''A''>Option A: Display verbose output<br><input type=''radio'' name=''answer_20'' value=''A''>Option B: Display verbose output<br><input type=''radio'' name=''answer_20'' value=''A''>Option C: Display only filenames<br><input type=''radio'' name=''answer_20'' value=''A''>Option D: Display version information<br><br>Question: 2<br>Which command is used to remove a file in UNIX?<br><input type=''radio'' name=''answer_10'' value=''A''>Option A: rm<br><input type=''radio'' name=''answer_10'' value=''A''>Option B: del<br><input type=''radio'' name=''answer_10'' value=''A''>Option C: remove<br><input type=''radio'' name=''answer_10'' value=''A''>Option D: delete<br><br>Question: 3<br>Which command is used to terminate a process in UNIX?<br><input type=''radio'' name=''answer_19'' value=''A''>Option A: kill<br><input type=''radio'' name=''answer_19'' value=''A''>Option B: stop<br><input type=''radio'' name=''answer_19'' value=''A''>Option C: end<br><input type=''radio'' name=''answer_19'' value=''A''>Option D: terminate<br><br>Question: 4<br>Which command is used to create a new directory in UNIX?<br><input type=''radio'' name=''answer_6'' value=''A''>Option A: newdir<br><input type=''radio'' name=''answer_6'' value=''A''>Option B: mkdir<br><input type=''radio'' name=''answer_6'' value=''A''>Option C: createdir<br><input type=''radio'' name=''answer_6'' value=''A''>Option D: makedir<br><br>Question: 5<br>What is the purpose of the ''chmod'' command in UNIX?<br><input type=''radio'' name=''answer_7'' value=''A''>Option A: Change file ownership<br><input type=''radio'' name=''answer_7'' value=''A''>Option B: Change file ownership<br><input type=''radio'' name=''answer_7'' value=''A''>Option C: Change file ownership<br><input type=''radio'' name=''answer_7'' value=''A''>Option D: Change file ownership<br><br>Question: 6<br>Which operating system is based on the UNIX architecture?<br><input type=''radio'' name=''answer_1'' value=''A''>Option A: Linux<br><input type=''radio'' name=''answer_1'' value=''A''>Option B: Windows<br><input type=''radio'' name=''answer_1'' value=''A''>Option C: macOS<br><input type=''radio'' name=''answer_1'' value=''A''>Option D: Android<br><br>Question: 7<br>Which command is used to display the current directory in UNIX?<br><input type=''radio'' name=''answer_3'' value=''A''>Option A: dir<br><input type=''radio'' name=''answer_3'' value=''A''>Option B: cd<br><input type=''radio'' name=''answer_3'' value=''A''>Option C: ls<br><input type=''radio'' name=''answer_3'' value=''A''>Option D: pwd<br><br>Question: 8<br>Which command is used to display the disk usage in UNIX?<br><input type=''radio'' name=''answer_15'' value=''A''>Option A: du<br><input type=''radio'' name=''answer_15'' value=''A''>Option B: df<br><input type=''radio'' name=''answer_15'' value=''A''>Option C: disk<br><input type=''radio'' name=''answer_15'' value=''A''>Option D: usage<br><br>Question: 9<br>Which UNIX command is used to display the contents of a file?<br><input type=''radio'' name=''answer_8'' value=''A''>Option A: print<br><input type=''radio'' name=''answer_8'' value=''A''>Option B: cat<br><input type=''radio'' name=''answer_8'' value=''A''>Option C: show<br><input type=''radio'' name=''answer_8'' value=''A''>Option D: view<br><br>Question: 10<br>What does the ''top'' command do in UNIX?<br><input type=''radio'' name=''answer_18'' value=''A''>Option A: Display system hardware information<br><input type=''radio'' name=''answer_18'' value=''A''>Option B: Display running processes and their resource usage<br><input type=''radio'' name=''answer_18'' value=''A''>Option C: . Display disk space usage<br><input type=''radio'' name=''answer_18'' value=''A''>Option D: . Display disk space usage<br><br>'),
(36, 'CS11070-Operating System With UNIX', 'question paper');

-- --------------------------------------------------------

--
-- Table structure for table `tmp_upload`
--

CREATE TABLE `tmp_upload` (
  `id` int(11) NOT NULL auto_increment,
  `subject` varchar(255) NOT NULL,
  `up_paper` varchar(10000) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=35 ;

--
-- Dumping data for table `tmp_upload`
--

INSERT INTO `tmp_upload` (`id`, `subject`, `up_paper`) VALUES
(34, 'Operating System With UNIX', 'Question: 1<br>Which command is used to create a symbolic link in UNIX?<br><input type=''radio'' name=''answer_17'' value=''A''>Option A: ln<br><input type=''radio'' name=''answer_17'' value=''A''>Option B: link<br><input type=''radio'' name=''answer_17'' value=''A''>Option C: symlink<br><input type=''radio'' name=''answer_17'' value=''A''>Option D: mklink<br><br>Question: 2<br>What does the ''grep -v'' command do in UNIX?<br><input type=''radio'' name=''answer_20'' value=''A''>Option A: Display verbose output<br><input type=''radio'' name=''answer_20'' value=''A''>Option B: Display verbose output<br><input type=''radio'' name=''answer_20'' value=''A''>Option C: Display only filenames<br><input type=''radio'' name=''answer_20'' value=''A''>Option D: Display version information<br><br>Question: 3<br>Which UNIX command is used to display the contents of a file?<br><input type=''radio'' name=''answer_8'' value=''A''>Option A: print<br><input type=''radio'' name=''answer_8'' value=''A''>Option B: cat<br><input type=''radio'' name=''answer_8'' value=''A''>Option C: show<br><input type=''radio'' name=''answer_8'' value=''A''>Option D: view<br><br>Question: 4<br>What does the ''top'' command do in UNIX?<br><input type=''radio'' name=''answer_18'' value=''A''>Option A: Display system hardware information<br><input type=''radio'' name=''answer_18'' value=''A''>Option B: Display running processes and their resource usage<br><input type=''radio'' name=''answer_18'' value=''A''>Option C: . Display disk space usage<br><input type=''radio'' name=''answer_18'' value=''A''>Option D: . Display disk space usage<br><br>Question: 5<br>What does the ''ps'' command do in UNIX?<br><input type=''radio'' name=''answer_14'' value=''A''>Option A: Print system information<br><input type=''radio'' name=''answer_14'' value=''A''>Option B: Display current processes<br><input type=''radio'' name=''answer_14'' value=''A''>Option C: Pause system operation<br><input type=''radio'' name=''answer_14'' value=''A''>Option D: Pause system operation<br><br>Question: 6<br>What is the purpose of the ''passwd'' command in UNIX?<br><input type=''radio'' name=''answer_16'' value=''A''>Option A: Print user passwords<br><input type=''radio'' name=''answer_16'' value=''A''>Option B: Change user password<br><input type=''radio'' name=''answer_16'' value=''A''>Option C: Delete user password<br><input type=''radio'' name=''answer_16'' value=''A''>Option D: View user password policy<br><br>Question: 7<br>What is the purpose of the ''tar'' command in UNIX?<br><input type=''radio'' name=''answer_11'' value=''A''>Option A: Create a new file<br><input type=''radio'' name=''answer_11'' value=''A''>Option B: Extract files from an archive<br><input type=''radio'' name=''answer_11'' value=''A''>Option C: Compress files into an archive<br><input type=''radio'' name=''answer_11'' value=''A''>Option D: Encrypt files<br><br>Question: 8<br>What does the ''grep'' command stand for in UNIX?<br><input type=''radio'' name=''answer_9'' value=''A''>Option A: Global regular expression print<br><input type=''radio'' name=''answer_9'' value=''A''>Option B: General regular expression program<br><input type=''radio'' name=''answer_9'' value=''A''>Option C: Global regular expression program<br><input type=''radio'' name=''answer_9'' value=''A''>Option D: General regular expression print<br><br>Question: 9<br>Which operating system is based on the UNIX architecture?<br><input type=''radio'' name=''answer_1'' value=''A''>Option A: Linux<br><input type=''radio'' name=''answer_1'' value=''A''>Option B: Windows<br><input type=''radio'' name=''answer_1'' value=''A''>Option C: macOS<br><input type=''radio'' name=''answer_1'' value=''A''>Option D: Android<br><br>Question: 10<br>What is the purpose of the ''chmod'' command in UNIX?<br><input type=''radio'' name=''answer_7'' value=''A''>Option A: Change file ownership<br><input type=''radio'' name=''answer_7'' value=''A''>Option B: Change file ownership<br><input type=''radio'' name=''answer_7'' value=''A''>Option C: Change file ownership<br><input type=''radio'' name=''answer_7'' value=''A''>Option D: Change file ownership<br><br>');

-- --------------------------------------------------------

--
-- Table structure for table `yea`
--

CREATE TABLE `yea` (
  `yid` int(11) NOT NULL,
  `year` int(11) default NULL,
  `program` varchar(255) default NULL,
  PRIMARY KEY  (`yid`),
  UNIQUE KEY `year` (`year`),
  KEY `program` (`program`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `yea`
--

INSERT INTO `yea` (`yid`, `year`, `program`) VALUES
(1, 1, 'BCA'),
(2, 2, 'BCA'),
(3, 3, 'BCA');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cour`
--
ALTER TABLE `cour`
  ADD CONSTRAINT `cour_ibfk_1` FOREIGN KEY (`sem`) REFERENCES `semester` (`sem`),
  ADD CONSTRAINT `cour_ibfk_2` FOREIGN KEY (`year`) REFERENCES `yea` (`year`),
  ADD CONSTRAINT `cour_ibfk_3` FOREIGN KEY (`program`) REFERENCES `pro` (`program`);

--
-- Constraints for table `generate_paper`
--
ALTER TABLE `generate_paper`
  ADD CONSTRAINT `generate_paper_ibfk_1` FOREIGN KEY (`courseco`) REFERENCES `cour` (`courseco`),
  ADD CONSTRAINT `generate_paper_ibfk_2` FOREIGN KEY (`courseid`) REFERENCES `cour` (`courseid`);

--
-- Constraints for table `give_exam`
--
ALTER TABLE `give_exam`
  ADD CONSTRAINT `give_exam_ibfk_1` FOREIGN KEY (`paperid`) REFERENCES `generate_paper` (`paper_id`),
  ADD CONSTRAINT `give_exam_ibfk_2` FOREIGN KEY (`rollno`) REFERENCES `reg_stu` (`rollno`);

--
-- Constraints for table `qbc10`
--
ALTER TABLE `qbc10`
  ADD CONSTRAINT `qbc10_ibfk_1` FOREIGN KEY (`courseid`) REFERENCES `cour` (`courseid`);

--
-- Constraints for table `qbc11`
--
ALTER TABLE `qbc11`
  ADD CONSTRAINT `qbc11_ibfk_1` FOREIGN KEY (`courseid`) REFERENCES `cour` (`courseid`);

--
-- Constraints for table `qbc12`
--
ALTER TABLE `qbc12`
  ADD CONSTRAINT `qbc12_ibfk_1` FOREIGN KEY (`courseid`) REFERENCES `cour` (`courseid`);

--
-- Constraints for table `qbco1`
--
ALTER TABLE `qbco1`
  ADD CONSTRAINT `qbco1_ibfk_1` FOREIGN KEY (`courseid`) REFERENCES `cour` (`courseid`);

--
-- Constraints for table `qbco2`
--
ALTER TABLE `qbco2`
  ADD CONSTRAINT `qbco2_ibfk_1` FOREIGN KEY (`courseid`) REFERENCES `cour` (`courseid`);

--
-- Constraints for table `qbco3`
--
ALTER TABLE `qbco3`
  ADD CONSTRAINT `qbco3_ibfk_1` FOREIGN KEY (`courseid`) REFERENCES `cour` (`courseid`);

--
-- Constraints for table `qbco4`
--
ALTER TABLE `qbco4`
  ADD CONSTRAINT `qbco4_ibfk_1` FOREIGN KEY (`courseid`) REFERENCES `cour` (`courseid`);

--
-- Constraints for table `qbco5`
--
ALTER TABLE `qbco5`
  ADD CONSTRAINT `qbco5_ibfk_1` FOREIGN KEY (`courseid`) REFERENCES `cour` (`courseid`);

--
-- Constraints for table `qbco6`
--
ALTER TABLE `qbco6`
  ADD CONSTRAINT `qbco6_ibfk_1` FOREIGN KEY (`courseid`) REFERENCES `cour` (`courseid`);

--
-- Constraints for table `qbco7`
--
ALTER TABLE `qbco7`
  ADD CONSTRAINT `qbco7_ibfk_1` FOREIGN KEY (`courseid`) REFERENCES `cour` (`courseid`);

--
-- Constraints for table `qbco8`
--
ALTER TABLE `qbco8`
  ADD CONSTRAINT `qbco8_ibfk_1` FOREIGN KEY (`courseid`) REFERENCES `cour` (`courseid`);

--
-- Constraints for table `qbco9`
--
ALTER TABLE `qbco9`
  ADD CONSTRAINT `qbco9_ibfk_1` FOREIGN KEY (`courseid`) REFERENCES `cour` (`courseid`);

--
-- Constraints for table `reg_fac`
--
ALTER TABLE `reg_fac`
  ADD CONSTRAINT `reg_fac_ibfk_1` FOREIGN KEY (`program`) REFERENCES `pro` (`program`);

--
-- Constraints for table `result`
--
ALTER TABLE `result`
  ADD CONSTRAINT `result_ibfk_1` FOREIGN KEY (`rollno`) REFERENCES `reg_stu` (`rollno`),
  ADD CONSTRAINT `result_ibfk_2` FOREIGN KEY (`paperid`) REFERENCES `generate_paper` (`paper_id`);

--
-- Constraints for table `schedule_exam`
--
ALTER TABLE `schedule_exam`
  ADD CONSTRAINT `schedule_exam_ibfk_1` FOREIGN KEY (`program`) REFERENCES `pro` (`program`),
  ADD CONSTRAINT `schedule_exam_ibfk_2` FOREIGN KEY (`year`) REFERENCES `yea` (`year`),
  ADD CONSTRAINT `schedule_exam_ibfk_3` FOREIGN KEY (`sem`) REFERENCES `semester` (`sem`),
  ADD CONSTRAINT `schedule_exam_ibfk_4` FOREIGN KEY (`course`) REFERENCES `cour` (`course`);

--
-- Constraints for table `semester`
--
ALTER TABLE `semester`
  ADD CONSTRAINT `semester_ibfk_1` FOREIGN KEY (`year`) REFERENCES `yea` (`year`),
  ADD CONSTRAINT `semester_ibfk_2` FOREIGN KEY (`program`) REFERENCES `pro` (`program`);

--
-- Constraints for table `store_paper`
--
ALTER TABLE `store_paper`
  ADD CONSTRAINT `store_paper_ibfk_1` FOREIGN KEY (`paperid`) REFERENCES `generate_paper` (`paper_id`);

--
-- Constraints for table `yea`
--
ALTER TABLE `yea`
  ADD CONSTRAINT `yea_ibfk_1` FOREIGN KEY (`program`) REFERENCES `pro` (`program`);
