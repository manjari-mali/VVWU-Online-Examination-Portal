<?php
session_start();

// Establish a connection to your database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "examination";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Escape user inputs for security
$scheduleid = mysqli_real_escape_string($conn, $_POST['scheduleid']);
$date_time = mysqli_real_escape_string($conn, $_POST['date_time']);
$program = mysqli_real_escape_string($conn, $_POST['program']);
$year = mysqli_real_escape_string($conn, $_POST['year']);
$sem = mysqli_real_escape_string($conn, $_POST['sem']);
$course = mysqli_real_escape_string($conn, $_POST['course']);

// Insert data into the database
$sql = "INSERT INTO schedule_exam (scheduleid, date_time, program, year, sem, course) 
        VALUES ('$scheduleid', '$date_time', '$program', '$year', '$sem', '$course')";

if ($conn->query($sql) === TRUE) {
    $_SESSION['status'] = "Exam schedule uploaded successfully";
    header("Location: schedule.php"); // Redirect back to the form page
    exit();
} else {
    $_SESSION['status'] = "Error: " . $sql . "<br>" . $conn->error;
    header("Location: schedule.php"); // Redirect back to the form page
    exit();
}

// Close database connection
$conn->close();
?>
