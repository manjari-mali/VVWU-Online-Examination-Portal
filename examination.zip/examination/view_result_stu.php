<?php
// Start the session at the beginning of the script
session_start();

// Check if user is logged in
if (!isset($_SESSION['email'])) {
    // Redirect user to login page if not logged in
    header("Location: homepage.php");
    exit(); // Stop further execution
}

// Fetch email from session
$email = $_SESSION['email'];

// Connect to the database
$conn = new mysqli('localhost', 'root', '', 'examination');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to select email, score, and date from exam_result table for the logged-in user
$query = "SELECT email, score, percentage, date FROM result_table WHERE email = ?";
$stmt = $conn->prepare($query);

if (!$stmt) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param('s', $email);
$stmt->execute();

if ($stmt->error) {
    die("Error executing statement: " . $stmt->error);
}

$stmt->bind_result($email, $score, $percentage, $date);

// Start HTML output
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam Results</title>
	<link rel="icon" href="image/logo.jpg" type="image/png">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }

        table {
            border-collapse: collapse;
            width: 80%;
            margin: 20px auto;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            background-color: #fff;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
            color: #333;
            font-weight: bold;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f2f2f2;
        }

        caption {
            font-size: 1.5em;
            margin-bottom: 10px;
            text-align: center;
            padding: 10px;
            background-color: #4e7ab8;
            color: #fff;
            border-radius: 8px 8px 0 0;
        }
    </style>
</head>
<body>
    <table>
        <caption>Exam Results</caption>
        <tr>
            <th>Email</th>
            <th>Score</th>
            <th>Percentage</th>
            <th>Date</th>
        </tr>
        <?php
        // Output data
        while ($stmt->fetch()) {
            echo "<tr>";
            echo "<td>$email</td>";
            echo "<td>$score</td>";
            echo "<td>$percentage%</td>";
            echo "<td>$date</td>";
            echo "</tr>";
        }
        ?>
    </table>
</body>
</html>

<?php
// Close the prepared statement and database connection
$stmt->close();
$conn->close();
?>
