<?php
session_start();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Registration Form</title>
	<link rel="icon" href="image/logo.jpg" type="image/png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Additional CSS for form styling */
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: #4e7ab8;
            color: #fff;
            border-radius: 10px 10px 0 0;
        }

        .form-group label {
            font-weight: bold;
            color: #333;
        }

        .btn-primary {
            background-color: #4e7ab8;
            border: none;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        input[type="datetime-local"],
        select.form-control {
            border: 1px solid #ced4da;
            border-radius: 5px;
            padding: 0.375rem 0.75rem;
            font-size: 1rem;
            line-height: 1.5;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }
    </style>
</head>
<body>
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-md-8">
					<?php
					if (isset($_SESSION['status'])) {
						?>
						<div class="alert alert-warning alert-dismissible fade show" role="alert">
							<?php echo $_SESSION['status']; ?>
							<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
						</div>
						<?php
						unset($_SESSION['status']);
					}
					?>
				<div class="card mt-5">
						<div class="card-header">
							<h4>Faculty Registration Form</h4>
						</div>
					<div class="card-body">
						<form method="post" action="register_fac.php" enctype="multipart/form-data">
							<div class="form-group mb-3">
								<label for="facid">Faculty ID:</label>
								<input type="text" id="facid" name="facid" class="form-control" required>
							</div>

							<div class="form-group mb-3">
								<label for="name">Faculty Name:</label>
								<input type="text" id="name" name="name" class="form-control" required>
							</div>
							<div class="form-group mb-3">
								<label for="email">Email:</label>
								<input type="email" id="email" name="email" class="form-control" pattern=".+@vvwusurat\.ac\.in$" required>
							</div>
							<div class="form-group mb-3">
								<label for="password">Password:</label>
								<input type="password" id="password" name="password" minlength="6" class="form-control" required>
							</div>
							<div class="form-group mb-3">
								<label for="contactno">Contact No:</label>
								<input type="text" id="contactno" name="contactno" pattern="[0-9]{10}" class="form-control" required>
							</div>
							<div class="form-group mb-3">
								<label for="dob">Date of Birth:</label>
								<input type="date" id="dob" name="dob" class="form-control" required>
							</div>
							<div class="form-group mb-3">
								<label for="doj">Date of Joining:</label>
								<input type="date" id="doj" name="doj" class="form-control" required>
							</div>
							<div class="form-group mb-3">
								<label for="gender">Gender:</label>
								<div class="form-control">
									<input type="radio" id="male" name="gender" value="male" required>
									<label for="male">Male</label>
									<input type="radio" id="female" name="gender" value="female" required>
									<label for="female">Female</label>
								</div>
							</div>
							<div class="form-group mb-3">
								<label for="program">Program:</label>
								<select name="program" id="program" class="form-control" required>
									<option value="BCA" selected>Bachelor of Computer Application(Hons.)</option>
								</select>
							</div>
							<div class="form-group mb-3">
								<label for="course1">Select Course:</label>
								<select name="course1" id="course1" class="form-control" required>
									<option value="" selected>Select Course1</option>
									<option value="CS11010-ICOA">CS11010-ICOA</option>
									<option value="CS11030-Programming Using C">CS11030-Programming Using C</option>
											<option value="CS11050-Programming Using C++">CS11050-Programming Using C++</option>
											<option value="CS11070-Operating System With UNIX">CS11070-Operating System With UNIX</option>
											<option value="CS11090-Data Structure">CS11090-Data Structure</option>
											<option value="CS11130-Programming Using JAVA">CS11130-Programming Using JAVA</option>
											<option value="CS11160-Programming Using Python">CS11160-Programming Using Python</option>
											<option value="CS51020-Internet Of Things">CS51020-Internet Of Things</option>
											<option value="CS11210-Computer Graphics">CS11210-Computer Graphics</option>
											<option value="CS11220-Web Development Using PHP">CS11220-Web Development Using PHP</option>
											<option value="CS14090-Cyber Security">CS14090-Cyber Security</option>
											<option value="CS14110-Digital Marketing">CS14110-Digital Marketing</option>
											<option value="None of these">None of these</option>
								</select>
							</div>
							<div class="form-group mb-3">
								<label for="course2">Select Course:</label>
								<select name="course2" id="course2" class="form-control" required>
									<option value="" selected>Select Course2</option>
							<option value="CS11010-ICOA">CS11010-ICOA</option>
											<option value="CS11030-Programming Using C">CS11030-Programming Using C</option>
											<option value="CS11050-Programming Using C++">CS11050-Programming Using C++</option>
											<option value="CS11070-Operating System With UNIX">CS11070-Operating System With UNIX</option>
											<option value="CS11090-Data Structure">CS11090-Data Structure</option>
											<option value="CS11130-Programming Using JAVA">CS11130-Programming Using JAVA</option>
											<option value="CS11160-Programming Using Python">CS11160-Programming Using Python</option>
											<option value="CS51020-Internet Of Things">CS51020-Internet Of Things</option>
											<option value="CS11210-Computer Graphics">CS11210-Computer Graphics</option>
											<option value="CS11220-Web Development Using PHP">CS11220-Web Development Using PHP</option>
											<option value="CS14090-Cyber Security">CS14090-Cyber Security</option>
											<option value="CS14110-Digital Marketing">CS14110-Digital Marketing</option>
											<option value="None of these">None of these</option>        <!-- Your options here -->
								</select>
							</div>
							<div class="form-group mb-3">
								<label for="course3">Select Course:</label>
								<select name="course3" id="course3" class="form-control" required>
									<option value="" selected>Select Course3</option>
							<option value="CS11010-ICOA">CS11010-ICOA</option>
											<option value="CS11030-Programming Using C">CS11030-Programming Using C</option>
											<option value="CS11050-Programming Using C++">CS11050-Programming Using C++</option>
											<option value="CS11070-Operating System With UNIX">CS11070-Operating System With UNIX</option>
											<option value="CS11090-Data Structure">CS11090-Data Structure</option>
											<option value="CS11130-Programming Using JAVA">CS11130-Programming Using JAVA</option>
											<option value="CS11160-Programming Using Python">CS11160-Programming Using Python</option>
											<option value="CS51020-Internet Of Things">CS51020-Internet Of Things</option>
											<option value="CS11210-Computer Graphics">CS11210-Computer Graphics</option>
											<option value="CS11220-Web Development Using PHP">CS11220-Web Development Using PHP</option>
											<option value="CS14090-Cyber Security">CS14090-Cyber Security</option>
											<option value="CS14110-Digital Marketing">CS14110-Digital Marketing</option>
											<option value="None of these">None of these</option>        <!-- Your options here -->
								</select>
							</div>
							<div class="form-group mb-3">
								<label for="course4">Select Course:</label>
								<select name="course4" id="course4" class="form-control" required>
									<option value="" selected>Select Course4</option>
							<option value="CS11010-ICOA">CS11010-ICOA</option>
											<option value="CS11030-Programming Using C">CS11030-Programming Using C</option>
											<option value="CS11050-Programming Using C++">CS11050-Programming Using C++</option>
											<option value="CS11070-Operating System With UNIX">CS11070-Operating System With UNIX</option>
											<option value="CS11090-Data Structure">CS11090-Data Structure</option>
											<option value="CS11130-Programming Using JAVA">CS11130-Programming Using JAVA</option>
											<option value="CS11160-Programming Using Python">CS11160-Programming Using Python</option>
											<option value="CS51020-Internet Of Things">CS51020-Internet Of Things</option>
											<option value="CS11210-Computer Graphics">CS11210-Computer Graphics</option>
											<option value="CS11220-Web Development Using PHP">CS11220-Web Development Using PHP</option>
											<option value="CS14090-Cyber Security">CS14090-Cyber Security</option>
											<option value="CS14110-Digital Marketing">CS14110-Digital Marketing</option>
											<option value="None of these">None of these</option>        <!-- Your options here -->
								</select>
							</div>
							<div class="form-group mb-3">
								<label for="profile_pic">Profile Picture:</label>
								<input type="file" id="profile_pic" name="profile_pic" class="form-control">
							</div>
							<div class="form-group mb-3">
								<button type="submit" name="submit" class="btn btn-primary">Upload</button>
								<!--<input type="submit" name="submit" value="Submit"> -->
							</div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>