<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: homepage.php"); // Redirect to login page if user is not logged in
    exit();
}

// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "examination";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = $_SESSION['email'];

// Retrieve faculty details from the database
$sql = "SELECT * FROM reg_stu WHERE email='$email'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output faculty details
    $row = $result->fetch_assoc();
	
} else {
    echo "No faculty found.";
    exit(); // Exit if faculty details not found
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
	<link rel="icon" href="image/logo.jpg" type="image/png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="sidebarcss.css">
</head>
<body>
<!-- Include header -->
    <?php include 'header.html'; ?>
    <!-- Include navigation bar -->
    <?php include 'newnavigation.html'; ?>
<div class="container">
    <div class="sidebar">
        <h2>Student Dashboard</h2>
        <ul>
           <li><a href="#" onclick="loadContent('my_pro_stu.php')"><i class="fas fa-user"></i>My profile</a></li>
           <li><a href="#" onclick="loadContent('view_schedule.php')"><i class="far fa-calendar-check"></i>View Schedule</a></li>
           <li><a href="#" onclick="loadContent('give_exam.php')"><i class="fas fa-file-alt"></i>Give Exam</a></li>
		   <li><a href="#" onclick="loadContent('view_result_stu.php')"><i class="fas fa-chart-bar"></i>View Result</a>
		   <li><a href="new_logout_stu.php" ><i class="fas fa-sign-out-alt"></i>Logout</a></li>
            <!-- Add more links as needed -->
        </ul>
    </div>
	<div class="content" id="content">
       <h2>Welcome, <?php echo $row['name']; ?>!</h2>
    </div>
	
</div>
<script src="sidebarjs.js"></script>
 <script>
function loadContent(page) {
    var contentDiv = document.getElementById("content");
    if (page === 'slider.html') {
        // Load content for Faculty
        contentDiv.innerHTML = `
            <button onclick="loadContent('faculty_registration.html')">Faculty Registration</button>
            <button onclick="loadContent('student_registration.html')">Student Registration</button>
        `;
    } else {
        // Load content for other pages
        contentDiv.innerHTML = '<iframe src="' + page + '" width="100%" height="100%" frameborder="0"></iframe>';
    }
}
</script>

<!-- Include footer -->
    <?php include 'footer.html'; ?>
</body>
</html>