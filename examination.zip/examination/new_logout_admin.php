<?php
session_start();

if(isset($_GET['confirm']) && $_GET['confirm'] == 'true') {
    // Unset all of the session variables
    //$_SESSION = array();

    // Destroy the session
    session_destroy();

    // Redirect to the login page or any other page after logout
    header("Location: homepage.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout</title>
	<link rel="icon" href="image/logo.jpg" type="image/png">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }
        .confirmation-message {
            width: 400px;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 40px;
            margin: 100px auto;
            text-align: center;
        }
        .confirmation-message h2 {
            margin-top: 0;
            color: #333;
        }
        .confirmation-message button {
            background-color: #0066FF;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 15px 20px;
            cursor: pointer;
        }
        .confirmation-message button:hover {
            background-color: #90A4AE;
        }
    </style>
</head>
<body>
<!-- Include header -->
<?php include 'header.html'; ?>
<!-- Include navigation bar -->
<?php include 'newnavigation.html'; ?>
    <br><br>
    <div class="confirmation-message">
        
        <h3>Are you sure you want to logout???</h3><br>
        <button onclick="confirmLogout()">
            <i class="fas fa-sign-out-alt"></i> Yes, Logout
        </button>
        <button onclick="cancelLogout()">Cancel</button>
    </div>

    <script>
        function confirmLogout() {
            window.location.href = "homepage.php?confirm=true";
        }

        function cancelLogout() {
            window.location.href = "dashboard_admin.php";
        }
    </script>
	<br><br>
	<!-- Include footer -->
<?php include 'footer.html'; ?>
</body>
</html>

