<!DOCTYPE html>
<html>
<head>
    <title>Emoji Feedback</title>
	<link rel="icon" href="image/logo.jpg" type="image/png">
    <style>
      body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            text-align: center;
        }
        
        .container {
            width: 50%; /* Adjust the width as needed */
            margin: 0 auto;
            background-color: #fff;
            border-radius: 10px;
            padding: 40px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h2 {
            color: #9c3848; /* Dark red color */
            font-size: 2em;
            margin-bottom: 20px;
            text-transform: uppercase; /* Uppercase text */
        }
        
        .slider {
            width: 100%; /* Adjust the width as needed */
            -webkit-appearance: none;
            appearance: none;
            height: 20px; /* Increased height */
            border-radius: 10px; /* Rounded border */
            background: linear-gradient(to right, #9c3848, #6c2e32); /* Gradient background in shades of red */
            outline: none;
            opacity: 0.8;
            -webkit-transition: .2s;
            transition: opacity .2s;
        }
        
        .slider:hover {
            opacity: 1;
        }
        
        .slider::-webkit-slider-thumb {
            -webkit-appearance: none;
            appearance: none;
            width: 30px; /* Increased width */
            height: 30px; /* Increased height */
            border-radius: 50%;
            background: #fff;
            cursor: pointer;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3); /* Soft shadow */
            border: 4px solid #9c3848; /* Border around thumb in dark red */
            -webkit-transition: .3s;
            transition: .3s;
        }
        
        .slider::-moz-range-thumb {
            width: 30px; /* Increased width */
            height: 30px; /* Increased height */
            border-radius: 50%;
            background: #fff;
            cursor: pointer;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3); /* Soft shadow */
            border: 4px solid #9c3848; /* Border around thumb in dark red */
            transition: .3s;
        }
        
        #emojiFeedback {
            font-size: 3em;
            transition: transform 0.5s;
            margin-top: 20px;
        }
        
        /* Styling for the submit button */
        input[type="submit"] {
            background-color: #4e7ab8; /* Dark red background */
            color: #fff; /* White text color */
            border: none; /* No border */
            border-radius: 5px; /* Rounded corners */
            padding: 10px 20px; /* Padding */
            font-size: 1.2em; /* Font size */
            cursor: pointer; /* Cursor style */
            transition: background-color 0.3s; /* Smooth transition */
        }

        input[type="submit"]:hover {
            background-color: #6c2e32; /* Darken the background color on hover */
        }

        /* Styling for the feedback success message */
        .success-message {
            color: brown; /* Green text color */
            font-size: 1.5em; /* Font size */
            margin-top: 20px; /* Margin top */
            font-weight: bold; /* Bold */
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3); /* Text shadow */
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Hey ! How was your exam ? </h2>
    <form method="post" action="">
        <input type="range" min="0" max="100" value="50" class="slider" id="mySlider" oninput="updateEmoji(this.value)">
        <p id="emojiFeedback">&#x1F600;</p>
        <input type="submit" value="Submit Feedback"></br></br></br>
    </form>
	   <?php
    // Check if the form was submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Display success message
        echo "<p class='success-message'>Feedback submitted successfully!</p>";
    }
    ?>
</div>

<script>
    // Update the emoji feedback when the page loads
    window.onload = function() {
        updateEmoji(document.getElementById('mySlider').value);
    }

    function updateEmoji(value) {
        let emoji = '';
        if (value <= 10) {
            emoji = '&#x1F621;'; // 😡
        } else if (value <= 30) {
            emoji = '&#x1F641;'; // 🙁
        } else if (value <= 50) {
            emoji = '&#x1F610;'; // 😐
        } else if (value <= 70) {
            emoji = '&#x1F60A;'; // 😊
        } else if (value <= 90) {
            emoji = '&#x1F603;'; // 😃
        } else {
            emoji = '&#x1F929;'; // 🤩
        }

        document.getElementById('emojiFeedback').innerHTML = emoji;
        // Add animation
        document.getElementById('emojiFeedback').style.transform = 'scale(1.2)';
        setTimeout(function() {
            document.getElementById('emojiFeedback').style.transform = 'scale(1)';
        }, 500);
    }
</script>

</body>
</html>
