<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage - Examination Portal</title>
	<link rel="icon" href="image/logo.jpg" type="image/png">
    <!-- Include your main CSS file -->
    <!--link rel="stylesheet" href="styles.css"-->
	
    <!-- Include slider specific CSS -->
    <link rel="stylesheet" href="slidercss.css">
</head>
<body>
    <!-- Include header -->
    <?php include 'header.html'; ?>
    <!-- Include navigation bar -->
    <?php include 'navigation.html'; ?>
    
    <!-- Include slider -->
    <?php include 'slider.html'; ?>
       
    <!-- Include footer -->
    <?php include 'footer.html'; ?>
    
    <!-- Include jQuery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <!-- Include GSAP -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.9.1/gsap.min.js"></script>
    <!-- Include slider specific JavaScript -->
    <script>
        (function($) {
    $(document).ready(function() {
      var s = $('.slider'),
          sWrapper = s.find('.slider-wrapper'),
          sItem = s.find('.slide'),
          btn = s.find('.slider-link'),
          sWidth = sItem.width(),
          sCount = sItem.length,
          slide_date = s.find('.slide-date'),
          slide_title = s.find('.slide-title'),
          slide_text = s.find('.slide-text'),
          slide_more = s.find('.slide-more'),
          slide_image = s.find('.slide-image img'),
          sTotalWidth = sCount * sWidth;

      sWrapper.css('width', sTotalWidth);

      var clickCount = 0;

      btn.on('click', function(e) {
        e.preventDefault();

        if ($(this).hasClass('next')) {
          (clickCount < (sCount - 1)) ? clickCount++ : clickCount = 0;
        } else if ($(this).hasClass('prev')) {
          (clickCount > 0) ? clickCount-- : (clickCount = sCount - 1);
        }

        TweenMax.to(sWrapper, 0.4, {x: '-' + (sWidth * clickCount)});

        //CONTENT ANIMATIONS
        var fromProperties = {autoAlpha:0, x:'-50', y:'-10'};
        var toProperties = {autoAlpha:0.8, x:'0', y:'0'};

        TweenLite.fromTo(slide_image, 1, {autoAlpha:0, y:'40'}, {autoAlpha:1, y:'0'});
        TweenLite.fromTo(slide_date, 0.4, fromProperties, toProperties);
        TweenLite.fromTo(slide_title, 0.6, fromProperties, toProperties);
        TweenLite.fromTo(slide_text, 0.8, fromProperties, toProperties);
        TweenLite.fromTo(slide_more, 1, fromProperties, toProperties);
      });
    });
  })(jQuery);
    </script>
</body>
</html>
